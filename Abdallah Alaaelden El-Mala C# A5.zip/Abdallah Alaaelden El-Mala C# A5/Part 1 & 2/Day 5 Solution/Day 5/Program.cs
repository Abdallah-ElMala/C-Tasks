﻿using System;

namespace Day_5
{
    internal class Program
    {
        #region TestDefensiveCode
        static int TestDefensiveCode()
        {
            int x, y;

            while (true)
            {
                Console.WriteLine("enter number x");
                if (int.TryParse(Console.ReadLine(), out x) && x > 0)
                    break;

                Console.WriteLine("invalid number");
            }

            while (true)
            {
                Console.WriteLine("enter number y");
                if (int.TryParse(Console.ReadLine(), out y) && y > 1)
                    break;

                Console.WriteLine("invalid number : ");
            }

            Console.Write("div = ");
            return x / y;
        }
        #endregion

        #region SumAndMultiplyy
        static void SumAndMultiply(int x, int y, out int sum, out int mul)
        {
            sum = x + y;
            mul = x * y;
        }
        #endregion

        #region optionalinteger
        static void optionalinteger(string x, int y = 5)
        {
            for (int i = 0; i < y; i++)
            {
                Console.WriteLine(x);
            }
        }
        #endregion

        #region sumarray
        static int sumarray(params int[] x)
        {
            int sum = 0;
            for (int i = 0; i < x.Length; i++)
            {
                sum += x[i];
            }
            return sum;
        }
        #endregion

        static void Main(string[] args)
        {
            //-------------------------- Part 1 ------------------------------

            #region problem 1
            //Console.WriteLine("enter two integer : ");
            // int.TryParse(Console.ReadLine(),out int x);
            //int.TryParse(Console.ReadLine(), out int y);

            //try
            //{
            //    int div = x / y;
            //    Console.WriteLine("division = "+div);
            //}
            //catch
            //{
            //    Console.WriteLine("cannot divide by zero ");
            //}
            //finally 
            //{
            //    Console.WriteLine("Operation complete ");            
            //}

            ////Question:
            //// do here job (print) even there is an error or not. 
            #endregion

            #region problem 2
            //Console.WriteLine(TestDefensiveCode());

            ////Question :
            ////int.TryParse() improves program robustness
            ////because it handles invalid user input without throwing an exception like int.parse. 
            #endregion

            #region problem 3
            //int? x = null;
            //int y = x ?? 0;
            //int? number = 10;

            //if (number.HasValue)
            //{
            //    Console.WriteLine("The number has a value.");
            //    Console.WriteLine($"Value = {number.Value}");
            //}
            //else
            //{
            //    Console.WriteLine("The number is null.");
            //} 

            //question :
            //InvalidOperationException
            #endregion

            #region problem 4
            //int[] arr = new int[5];

            //try
            //{
            //    Console.WriteLine(arr[5]);
            //}
            //catch (IndexOutOfRangeException)
            //{
            //    Console.WriteLine("index out of range");
            //}

            ////question:
            ////We check array bounds to prevent accessing invalid indexes and avoid IndexOutOfRangeException. 
            #endregion

            #region problem 5
            //int[,] arr = new int[3,3];

            //for (int i = 0; i < arr.GetLength(0); i++)
            //{

            //    for (int j = 0; j < arr.GetLength(1); j++)
            //    {
            //        Console.WriteLine($"index :[{i} , {j}] =");
            //        int.TryParse(Console.ReadLine(),out arr[i,j]);
            //    }
            //}
            //Console.Clear();

            //for (int i = 0; i < arr.GetLength(0); i++)
            //{
            //    int sum1 = 0;
            //    for (int j = 0; j < arr.GetLength(1); j++)
            //    {
            //        sum1 += arr[i,j];
            //    }
            //    Console.WriteLine($"sum of raws {i+1} = {sum1}");
            //}
            //Console.WriteLine("---------------------------------------");
            //for (int i = 0; i < arr.GetLength(1); i++)
            //{
            //    int sum1 = 0;
            //    for (int j = 0; j < arr.GetLength(0); j++)
            //    {
            //        sum1 += arr[j,i];
            //    }
            //    Console.WriteLine($"sum of columns {i + 1} = {sum1}");
            //} 
            #endregion

            #region problem 6
            //int[][] arr = new int[3][];
            //arr[0] = new int[4];
            //arr[1] = new int[3];
            //arr[2] = new int[2];

            //for (int i = 0; i < arr.Length; i++)
            //{
            //    for (int j = 0; j < arr[i].Length;j++)
            //    {
            //        Console.WriteLine($"INDEX [{i},{j}] = ");
            //        int.TryParse(Console.ReadLine(),out arr[i][j]);
            //    }
            //}
            //Console.Clear();

            //for (int i = 0;i < arr.Length; i++)
            //{

            //    Console.WriteLine($"raw {i+1} : ");
            //    for (int j = 0; j < arr[i].Length; j++)
            //    {

            //        Console.WriteLine(arr[i][j]);
            //    }
            //}

            ////Question :
            ////Rectangular Array = one 2D array with fixed dimensions.
            ////Jagged Array = array of separate arrays, so each row can have a different size. 
            #endregion

            #region problem 7
            //#nullable enable
            //string? x = Console.ReadLine();
            //Console.WriteLine(x!.Length);

            ////Question : 
            ////Nullable reference types help identify possible null-reference errors at compile time
            ////by allowing developers to explicitly specify whether a reference type can contain null. 
            #endregion

            #region problem 8
            ////boxing:
            //int x = 10;
            //object obj = x;
            ////unboxing:
            //int y = (int)obj;
            //try
            //{
            //    string text = (string)obj; 
            //}
            //catch (InvalidCastException)
            //{
            //    Console.WriteLine("Invalid cast!");
            //}
            //Console.WriteLine(obj);
            //Console.WriteLine(y);

            ////Question : 
            ////Boxing and unboxing can reduce performance because boxing requires heap allocation and copying,
            ////while unboxing requires type checking and copying the value back.
            ////Excessive boxing also increases Garbage Collector pressure.
            ////Generics such as List<int> can help avoid unnecessary boxing. 
            #endregion

            #region problem 9
            //int sum, mul;
            //SumAndMultiply(5,10,out sum,out mul);
            //Console.WriteLine(sum +" , "+ mul); 

            //Question :
            //An out parameter must be assigned a value inside the method before the method returns,
            //because the caller is not required to initialize it before passing it.
            #endregion

            #region problem 10
            //optionalinteger("ali",2);
            //Console.WriteLine("------------------------");
            //optionalinteger(y:3,x:"ali");

            ////question :
            ////Optional parameters must appear at the end of a method's parameter list
            ////so the compiler can clearly determine
            ////which arguments are provided and which should use their default values. 
            #endregion

            #region problem 11
            //#nullable enable
            //int[]? arr = null;

            //Console.WriteLine(arr?.Length);

            ////question :
            ////The null propagation operator (?.) safely accesses a member only if the object is not null.
            ////If the object is null, it returns null instead of throwing a NullReferenceException 
            #endregion

            #region problem 12
            //Console.Write("enter day name : ");
            //string x = Console.ReadLine();

            //int num = x switch
            //{

            //    "Monday" => 1,
            //    "Tuesday" => 2,
            //    "Wednesday" => 3,
            //    "Thursday" => 4,
            //    "Friday" => 5,
            //    "Saturday" => 6,
            //    "Sunday" => 7,
            //    _=>0
            //};
            //Console.WriteLine("number = "+num);

            ////question
            ////A switch expression is preferred when you need to compare one value
            ////against multiple possible patterns or values and return a result for each case.
            ////It is usually more concise and readable than multiple if-else statements. 
            #endregion

            #region problem 13

            //Console.WriteLine(sumarray(1, 2, 5, 8, 7));

            ////question :
            ////The params parameter must be the last parameter,
            ////only one params parameter is allowed per method, and it must be a one-dimensional array. 
            #endregion


            //---------------------------------------- Part 2 ---------------------------------------

            #region problem 1
            //Console.WriteLine("enter the number : ");
            //int.TryParse(Console.ReadLine(),out int x);
            //if (x>0)
            //{
            //    for (int i = 1; i <= x; i++)
            //    {
            //        Console.WriteLine(i+"  ");
            //    }
            //} 
            #endregion

            #region problem 2

            //Console.WriteLine("enter the number : ");
            //int.TryParse(Console.ReadLine(),out int x);

            //for (int i = 1; i <= 12; i++)
            //{
            //    Console.Write($"{i*x}, ");

            //} 
            #endregion

            #region problem 3
            //Console.WriteLine("enyer the number : ");
            //int.TryParse(Console.ReadLine(), out int x);

            //for (int i = 1; i <= x;i++)
            //{
            //    if (i % 2 == 0)
            //    {
            //        Console.Write($"{i}, ");
            //    }

            //} 
            #endregion

            #region problem 4
            //Console.WriteLine("enter the two number : ");
            //int.TryParse(Console.ReadLine(),out int x);
            //int.TryParse(Console.ReadLine(),out int y);
            //int mul=1;
            //for (int i = 0; i < y; i++)
            //{
            //   mul *= x;

            //}
            //Console.WriteLine(mul); 
            #endregion

            #region problem 5
            //Console.WriteLine("enter text : ");
            //string text = Console.ReadLine();
            //for (int i = text.Length-1; i >= 0; i--)
            //{
            //    Console.Write(text[i]);
            //} 
            #endregion

            #region problem 6
            //Console.Write("Enter an integer: ");
            //int number = int.Parse(Console.ReadLine());

            //int reversed = 0;

            //while (number != 0)
            //{
            //    int digit = number % 10;
            //    reversed = reversed * 10 + digit;
            //    number /= 10;
            //}

            //Console.WriteLine($"Reversed = {reversed}"); 
            #endregion

            #region problem 7
            //int[] arr = { 7, 0, 0, 0, 0, 5, 6, 7, 5, 0, 7, 5, 3 };

            //int maxDistance = 0;

            //for (int i = 0; i < arr.Length; i++)
            //{
            //    for (int j = i + 1; j < arr.Length; j++)
            //    {
            //        if (arr[i] == arr[j])
            //        {
            //            int distance = j - i - 1;

            //            if (distance > maxDistance)
            //            {
            //                maxDistance = distance;
            //            }
            //        }
            //    }
            //}

            //Console.WriteLine($"Longest distance = {maxDistance}"); 
            #endregion

            #region problem 8
            //Console.Write("Enter array size: ");
            //int n = int.Parse(Console.ReadLine());

            //int[] arr = new int[n];

            //for (int i = 0; i < arr.Length; i++)
            //{
            //    Console.Write($"Enter element {i}: ");
            //    arr[i] = int.Parse(Console.ReadLine());
            //}

            //int maxDistance = 0;

            //for (int i = 0; i < arr.Length; i++)
            //{
            //    for (int j = i + 1; j < arr.Length; j++)
            //    {
            //        if (arr[i] == arr[j])
            //        {
            //            int distance = j - i - 1;

            //            if (distance > maxDistance)
            //            {
            //                maxDistance = distance;
            //            }
            //        }
            //    }
            //}

            //Console.WriteLine($"Longest distance = {maxDistance}"); 
            #endregion

            #region problem 9
            //Console.Write("Enter a sentence: ");
            //string sentence = Console.ReadLine();

            //string[] words = sentence.Split(' ');

            //for (int i = 0; i < words.Length / 2; i++)
            //{
            //    string temp = words[i];
            //    words[i] = words[words.Length - 1 - i];
            //    words[words.Length - 1 - i] = temp;
            //}

            //Console.WriteLine(string.Join(" ", words)); 
            #endregion




        }
    }
}
