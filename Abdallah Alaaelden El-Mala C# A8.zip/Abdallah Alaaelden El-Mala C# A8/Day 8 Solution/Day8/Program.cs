﻿using System;

namespace Day8
{
    // ---------------------------- part 1 ----------------------------
    #region IVehicle
    interface IVehicle
    {
        void StartEngine();
        void StopEngine();
    }
    class Car : IVehicle
    {
        public void StartEngine()
        { Console.WriteLine("Car engine started."); }
        public void StopEngine()
        { Console.WriteLine("Car engine stopped."); }
    }
    class Bike : IVehicle
    {
        public void StartEngine()
        { Console.WriteLine("Bike engine started."); }

        public void StopEngine()
        { Console.WriteLine("Bike engine stopped."); }
    }
    #endregion

    #region shape
    abstract class Shape
    {
        public abstract double GetArea();

        public void Display()
        { Console.WriteLine("This is a shape."); }
    }
    class Rectangle : Shape
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }
        public override double GetArea()
        { return Width * Height; }
    }
    class Circle : Shape
    {
        public double Radius { get; set; }
        public Circle(double radius)
        { Radius = radius; }
        public override double GetArea()
        { return Math.PI * Radius * Radius; }
    }
    #endregion

    #region compare to
    class Product : IComparable<Product>
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }

        public int CompareTo(Product other)
        {
            return Price.CompareTo(other.Price);
        }
    }
    #endregion

    #region copy ctor
    class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Grade { get; set; }

        public Student(int id, string name, double grade)
        {
            Id = id;
            Name = name;
            Grade = grade;
        }

        public Student(Student other)
        {
            Id = other.Id;
            Name = other.Name;
            Grade = other.Grade;
        }
    }
    #endregion

    #region IWalkable
    public interface IWalkable
    { void Walk(); }

    public class Robot : IWalkable
    {
        public void Walk()
        { Console.WriteLine("Robot default walk method."); }

        void IWalkable.Walk() 
        { Console.WriteLine("Robot walking as IWalkable."); }
    }
    #endregion

    #region struct
    struct Account
    {
        private int AccountId;
        private string AccountHolder;
        private double Balance;

        public int Id
        {
            get { return AccountId; }
            set { AccountId = value; }
        }

        public string Holder
        {
            get { return AccountHolder; }
            set { AccountHolder = value; }
        }

        public double Amount
        {
            get { return Balance; }
            set { Balance = value; }
        }
    }
    #endregion

    #region ILogger
    interface ILogger
    {
        void Log()
        { Console.WriteLine("Default Log"); }
    }
    class ConsoleLogger : ILogger
    {
        public void Log()
        { Console.WriteLine("Console Logger"); }
    }

    #endregion

    #region book
    class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }

        public Book()
        {
            Title = "Unknown";
            Author = "Unknown";
        }
        public Book(string title)
        {
            Title = title;
            Author = "Unknown";
        }
        public Book(string title, string author)
        {
            Title = title;
            Author = author;
        }
        public void Display()
        { Console.WriteLine($"Title: {Title}, Author: {Author}"); }
    }
    #endregion

    // ---------------------------- part 2 ----------------------------
    #region Create a Shape Series
    interface IShapeSeries
    {
        int CurrentShapeArea { get; set; }

        void GetNextArea();

        void ResetSeries();
    }
    class SquareSeries : IShapeSeries
    {
        private int side = 0;

        public int CurrentShapeArea { get; set; }

        public void GetNextArea()
        {
            side++;
            CurrentShapeArea = side * side;
        }
        public void ResetSeries()
        {
            side = 0;
            CurrentShapeArea = 0;
        }
    }
    class CircleSeries : IShapeSeries
    {
        private int radius = 0;

        public int CurrentShapeArea { get; set; }

        public void GetNextArea()
        {
            radius++;
            CurrentShapeArea = (int)(Math.PI * radius * radius);
        }
        public void ResetSeries()
        {
            radius = 0;
            CurrentShapeArea = 0;
        }
    }
    #endregion

    #region Implement Sorting for Shapes
    class Shape1 : IComparable<Shape1>
    {
        public string Name { get; set; }
        public double Area { get; set; }

        public int CompareTo(Shape1 other)
        {
            return Area.CompareTo(other.Area);
        }
    }
    #endregion

    #region Extend the Shape Hierarchy
    abstract class GeometricShape
    {
        public double Dimension1 { get; set; }
        public double Dimension2 { get; set; }

        public abstract double CalculateArea();

        public abstract double Perimeter { get; }
    }
    class Triangle : GeometricShape
    {
        public override double CalculateArea()
        {
            return 0.5 * Dimension1 * Dimension2;
        }
        public override double Perimeter
        {
            get
            {
                return Dimension1 + Dimension2;
            }
        }
    }

    class Rectangle1 : GeometricShape
    {
        public override double CalculateArea()
        {
            return Dimension1 * Dimension2;
        }

        public override double Perimeter
        {
            get
            {
                return 2 * (Dimension1 + Dimension2);
            }
        }
    }
    #endregion

    internal class Program
    {
        #region PrintTenShapes
        static void PrintTenShapes(IShapeSeries series)
        {
            series.ResetSeries();

            for (int i = 0; i < 10; i++)
            {
                series.GetNextArea();
                Console.WriteLine(series.CurrentShapeArea);
            }
        }
        #endregion

        #region Implement Your Own Sorting — Selection Sort
        public static void SelectionSort(int[] numbers)
        {
            for (int i = 0; i < numbers.Length - 1; i++)
            {
                int minIndex = i;

                for (int j = i + 1; j < numbers.Length; j++)
                {
                    if (numbers[j] < numbers[minIndex])
                    {
                        minIndex = j;
                    }
                }
                int temp = numbers[i];
                numbers[i] = numbers[minIndex];
                numbers[minIndex] = temp;
            }
        }
        #endregion

        static void Main(string[] args)
        {
            // ---------------------------- part 1 ----------------------------
            #region problem 1

            //IVehicle car = new Car();
            //IVehicle bike = new Bike();
            //car.StartEngine();
            //car.StopEngine();
            //bike.StartEngine();
            //bike.StopEngine();

            // Question -> Why is it better to code against an interface rather than a concrete class?
            // 1. It reduces tight coupling between classes.
            // 2. It allows easy swapping of implementations without changing client code.
            // 3. It improves code testability using mock objects.
            // 4. It supports flexibility and extensibility in software design.

            #endregion

            #region problem 2

            //Shape rectangle = new Rectangle(5, 4);
            //Shape circle = new Circle(3);
            //rectangle.Display();
            //Console.WriteLine(rectangle.GetArea());
            //circle.Display();
            //Console.WriteLine(circle.GetArea());

            // Question -> When should you prefer an abstract class over an interface?
            // 1. When sharing common code and default behavior among related classes.
            // 2. When defining non-public (protected/internal) members or fields.
            // 3. When creating a close "is-a" logical hierarchy between classes.
            // 4. When adding new functionality in the future without breaking child classes.

            #endregion

            #region problem 3
            //Product[] products = {
            //new Product { Id = 1, Name = "Laptop", Price = 20000 },
            //new Product { Id = 2, Name = "Mouse", Price = 250 },
            //new Product { Id = 3, Name = "Keyboard", Price = 750 }
            // };

            //Array.Sort(products);

            //foreach (Product product in products)
            //{
            //    Console.WriteLine($"{product.Name} -> {product.Price}");
            //}

            // Question -> How does implementing IComparable improve flexibility in sorting?
            // 1. It allows standard framework methods like Array.Sort() to work automatically.
            // 2. It defines a natural, consistent sorting order for custom objects.
            // 3. It decouples the sorting logic from external algorithm code.
            // 4. It enables sorting collections without writing custom comparison methods every time.

            #endregion

            #region problem 4
            //Student student1 = new Student(1, "Abdallah", 90);
            //Student student2 = new Student(student1);
            //student2.Name = "Mohamed";
            //Console.WriteLine($"1st student name: {student1.Name}, 2nd student name: {student2.Name}");

            // Question -> What is the primary purpose of a copy constructor in C#?
            // 1. To create an independent duplicate copy of an existing object.
            // 2. To prevent unwanted shared references and side effects in code.
            // 3. To ensure modifications to the new copy do not alter the original object.
            // 4. To simplify deep cloning of custom reference types.

            #endregion

            #region problem 5
            //Robot r = new Robot();
            //r.Walk(); 

            //IWalkable w = r;
            //w.Walk(); 

            // Question -> How does explicit interface implementation help in resolving naming conflicts?
            // 1. It disambiguates methods with identical names from multiple interfaces.
            // 2. It hides interface methods from the concrete class's public API directly.
            // 3. It allows separate logic implementations for class methods and interface methods.
            // 4. It enforces casting to the interface type to access explicit members.

            #endregion

            #region problem 6
            //Account account = new Account();

            //account.Id = 101;
            //account.Holder = "Abdo";
            //account.Amount = 5000;
            //Console.WriteLine($"ID: {account.Id}, Holder: {account.Holder}, Amount: {account.Amount}");

            // Question -> What is the key difference between encapsulation in structs and classes?
            // 1. Structs are value types stored on the stack; classes are reference types on the heap.
            // 2. Copying a struct creates a full copy of encapsulated data, not a shared reference.
            // 3. Struct fields cannot be initialized directly at declaration (prior to C# 10).
            // 4. Structs are immutable by design standard practices, whereas classes are often mutable.

            // Question -> What is abstraction as a guideline, what's its relation with encapsulation?
            // 1. Abstraction focuses on showing what an object does while hiding how it works.
            // 2. Encapsulation is the tool that implements abstraction by grouping and restricting data access.
            // 3. Abstraction operates at the design level; encapsulation operates at the implementation level.
            // 4. Together, they simplify complex systems and protect object state from invalid changes.

            #endregion

            #region problem 7
            //ILogger logger = new ConsoleLogger();
            //logger.Log();

            // Question -> How do default interface implementations affect backward compatibility in C#?
            // 1. They allow adding new methods to interfaces without breaking existing implementations.
            // 2. Existing implementing classes do not need to rewrite code for new interface features.
            // 3. They reduce the need for creating wrapper or adapter classes over time.
            // 4. They enable safer updates to published APIs across large library versions.

            #endregion

            #region problem 8
            //Book book1 = new Book();
            //Book book2 = new Book("C# Programming");
            //Book book3 = new Book("Clean Code", "Lional Messi (10) ");
            //book1.Display();
            //book2.Display();
            //book3.Display();

            // Question -> How does constructor overloading improve class usability?
            // 1. It provides multiple flexible ways to instantiate an object based on available data.
            // 2. It simplifies object creation by supplying sensible default values.
            // 3. It reduces duplicate initialization code across constructors.
            // 4. It makes class instantiation cleaner and more convenient for callers.

            #endregion

            // ---------------------------- part 2 ----------------------------

            #region Question 2:
            //It means that we declare variables and write code using the
            //interface type instead of depending directly on a specific class.
            ///////////////////
            //It means that our code should depend on general contracts such as interfaces or abstract classes,
            //rather than specific implementations. 
            #endregion

            #region Question 3:
            //Abstraction as a guideline means that we should hide unnecessary implementation details
            //and expose only the important functionality. 
            #endregion

            #region Ishape series
            //IShapeSeries square = new SquareSeries();

            //Console.WriteLine("Square Series:");
            //PrintTenShapes(square);

            //IShapeSeries circle = new CircleSeries();

            //Console.WriteLine("\nCircle Series:");
            //PrintTenShapes(circle); 
            #endregion

            #region Implement Sorting for Shapes
            //    Shape1[] shapes =
            //  {
            //    new Shape1 { Name = "Square", Area = 25 },
            //    new Shape1 { Name = "Circle", Area = 12.56 },
            //    new Shape1 { Name = "Rectangle", Area = 40 },
            //    new Shape1 { Name = "Triangle", Area = 15 }
            //};
            //    Array.Sort(shapes);

            //    foreach (Shape1 shape in shapes)
            //    {
            //        Console.WriteLine($"{shape.Name} - Area: {shape.Area}");
            //    } 
            #endregion

            #region Extend the Shape Hierarchy
            //GeometricShape triangle = new Triangle
            //{
            //    Dimension1 = 10,
            //    Dimension2 = 5
            //};

            //GeometricShape rectangle = new Rectangle1
            //{
            //    Dimension1 = 10,
            //    Dimension2 = 5
            //};

            //Console.WriteLine("Triangle Area: " + triangle.CalculateArea());
            //Console.WriteLine("Rectangle Area: " + rectangle.CalculateArea());

            //Console.WriteLine("Rectangle Perimeter: " + rectangle.Perimeter); 
            #endregion

            #region Implement Your Own Sorting — Selection Sort
            //int[] numbers = { 25, 10, 40, 15, 5 };

            //SelectionSort(numbers);

            //foreach (int number in numbers)
            //{
            //    Console.WriteLine(number);
            //}
            #endregion

        }
    }
}
