﻿using System;
using System.Collections.Generic;
using System.Buffers.Text;
using System.Drawing;
using System.Reflection.Metadata;
using System.Text.RegularExpressions;

namespace Day_9
{
    // --------------------------------- part 1 ---------------------------------
    #region Weekdays
    enum Weekdays
    {
        Monday = 1,
        Tuesday,
        Wednesday,
        Thursday,
        Friday
    }
    #endregion

    #region grades
    enum grades : short
    {
        f = -1,
        a,
        b,
        c,
        d,
        e
    }
    #endregion

    #region person
    class person
    {
        public int id { get; set; }
        public string name { get; set; }
        public string department { get; set; }

        public void dis()
        {
            Console.WriteLine(id);
            Console.WriteLine(name);
            Console.WriteLine(department);
            Console.WriteLine();
        }
    }
    #endregion

    #region salary
    class Person
    {
        public virtual decimal Salary { get; set; }
    }

    class Child : Person
    {
        public sealed override decimal Salary
        {
            get { return base.Salary; }
            set { base.Salary = value; }
        }

        public void DisplaySalary()
        {
            Console.WriteLine($"Salary: {Salary}");
        }
    }
    #endregion

    #region utility
    class utility
    {
        public static double perimeter(double l, double w)
        {
            return 2 * (l + w);
        }

    }
    #endregion

    #region complexnumber
    class ComplexNumber
    {
        double Real { get; set; }
        double Imaginary { get; set; }

        public ComplexNumber(double real, double imaginary)
        {
            Real = real;
            Imaginary = imaginary;
        }
        public static ComplexNumber operator *(ComplexNumber a, ComplexNumber b)
        {
            return new ComplexNumber
            (
                a.Real * b.Real - a.Imaginary * b.Imaginary,
            a.Real * b.Imaginary + a.Imaginary * b.Real
            );
        }
        public override string ToString()
        {
            return $"{Real} + {Imaginary}i";
        }
    }
    #endregion

    #region gender
    enum GenderInt
    {
        Male,
        Female
    }

    enum GenderByte : byte
    {
        Male,
        Female
    }
    #endregion

    #region Utility2
    class Utility
    {
        public static double CelsiusToFahrenheit(double celsius)
        {
            return (celsius * 9 / 5) + 32;
        }

        public static double FahrenheitToCelsius(double fahrenheit)
        {
            return (fahrenheit - 32) * 5 / 9;
        }
    }
    #endregion

    #region grades2
    enum Grades
    {
        F,
        D,
        C,
        B,
        A
    }
    #endregion

    #region employee
    class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public override bool Equals(object obj)
        {
            if (obj is Employee other)
            {
                return Id == other.Id;
            }

            return false;
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }
    }
    class Helper2<T>
    {
        public static int SearchArray(T[] array, T value)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (Equals(array[i], value))
                    return i;
            }

            return -1;
        }
        //new question replace array:
        public static void replacearr(T[] x, T old, T neww)
        {
            for (int i = 0; i < x.Length; i++)
            {
                if (Equals(x[i], old))
                {
                    x[i] = neww;
                }

            }

        }

    }
    #endregion

    #region helper max
    class Helper
    {
        public static T Max<T>(T a, T b) where T : IComparable
        {
            return a.CompareTo(b) > 0 ? a : b;
        }
    }
    #endregion

    #region swap
    struct rectangle
    {
        public double w { get; set; }
        public double h { get; set; }


    }
    class helper
    {
        public static void Swap(ref rectangle x, ref rectangle y)
        {
            rectangle temp = x;
            x = y;
            y = temp;
        }
    }
    #endregion

    #region department
    class Department
    {
        public string Name { get; set; }

        public override bool Equals(object obj)
        {
            if (obj is Department other)
            {
                return Name == other.Name;
            }
            return false;
        }
        public override int GetHashCode()
        {
            return Name?.GetHashCode() ?? 0;
        }
    }
    class employee
    {
        public string Name { get; set; }
        public int Id { get; set; }

        public Department department { get; set; }

        public override bool Equals(object obj)
        {
            if (obj is employee other)
            {
                return Id == other.Id;
            }
            return false;
        }
        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

    }
    #endregion

    #region circle class and struct
    struct CircleStruct
    {
        public double Radius { get; set; }
        public string Color { get; set; }

        public static bool operator ==(CircleStruct c1, CircleStruct c2)
        {
            return c1.Radius == c2.Radius &&
                   c1.Color == c2.Color;
        }

        public static bool operator !=(CircleStruct c1, CircleStruct c2)
        {
            return !(c1 == c2);
        }

        public override bool Equals(object obj)
        {
            if (obj is CircleStruct other)
                return this == other;

            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Radius, Color);
        }
    }
    class CircleClass
    {
        public double Radius { get; set; }
        public string Color { get; set; }

        public override bool Equals(object obj)
        {
            if (obj is CircleClass other)
            {
                return Radius == other.Radius &&
                       Color == other.Color;
            }

            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Radius, Color);
        }
    }
    #endregion

    // --------------------------------- part 2 ---------------------------------
    #region reverse array
    class reversearray
    {
        public static T[] Revarr<T>(T[] arr)
        {
            T[] reasult = new T[arr.Length];
            for (int i = 0; i < arr.Length; i++)
            {
                reasult[i] = arr[arr.Length - 1 - i];
            }
            return reasult;


        }
    }
    #endregion

    #region stack
    class stack<T>
    {
        private List<T> items = new List<T>();

        public void push(T x)
        {
            items.Add(x);
        }
        public T pop()
        {
            if (items.Count == 0)
            {
                Console.WriteLine("emptyyy");
            }
            T item = items[items.Count - 1];
            items.RemoveAt(items.Count - 1);
            return item;
        }
        public T peek()
        {
            if (items.Count == 0)
            {
                Console.WriteLine("is emptyyyy");
            }

            return items[items.Count - 1];
        }
    }
    #endregion

    #region swap array
    class swapelement<T>
    {
        public static void swaparray(T[] arr, int swap1, int swap2)
        {
            T temp = arr[swap1];
            arr[swap1] = arr[swap2];
            arr[swap2] = temp;

        }
    }
    #endregion

    #region max array
    class maxarray<T> where T : IComparable<T>
    {
        public static T max(T[] arr)
        {
            if (arr == null || arr.Length == 0)
            {
                throw new ArgumentException("Array cannot be null or empty.");
            }
            T maxx = arr[0];
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].CompareTo(maxx) > 0)
                {
                    maxx = arr[i];
                }
            }
            return maxx;
        }
    }
    #endregion



    internal class Program
    {
        static void Main(string[] args)
        {
            // --------------------------------- part 1 ---------------------------------
            #region weekdays
            //foreach (Weekdays day in Enum.GetValues(typeof(Weekdays)))
            //{
            //    Console.WriteLine($"{day} = {(int)day}");
            //}

            ////question :
            ////Because explicit values make the enum values predictable and clear,
            ////especially when the values are stored in a database,
            ////exchanged with another system, or must match predefined values. 
            #endregion

            #region grades
            //foreach (grades g in Enum.GetValues(typeof(grades)))
            //{
            //    Console.WriteLine($"{g}={(short)g}");
            //}

            ////question :
            ////The value cannot be represented by the underlying type. With a compile-time constant,
            ////the compiler reports an error because the value is outside the allowed range. 
            #endregion

            #region DEPARTMENT
            //person p1 = new person()
            //{
            //    id = 2,
            //    name = "alia",
            //    department = "IR"
            //};
            //person p2 = new person()
            //{
            //    id = 1,
            //    name = "ali",
            //    department = "IT"
            //};   
            //p1.dis();
            //p2.dis(); 

            //question :
            //virtual allows a derived class to override the property and provide its own implementation.

            #endregion

            #region salary
            //Child child = new Child();
            //child.Salary = 5000;

            //child.DisplaySalary(); 

            //question :
            //Because sealed prevents further derived classes from overriding that member.
            //It stops the inheritance chain for that specific member.

            #endregion

            #region utility
            //double res = utility.perimeter(10, 5);
            //Console.WriteLine(res);

            //question ;
            // Static members belong to the class itself and can be accessed without creating an object.
            //Object(instance) members belong to a specific object and require an instance.
            #endregion

            #region complexnumber
            //ComplexNumber c1 = new ComplexNumber(2, 3);
            //ComplexNumber c2 = new ComplexNumber(4, 5);

            //ComplexNumber result = c1 * c2;

            //Console.WriteLine(result); 

            //question :
            //No. C# allows overloading many operators, but not all of them.
            //Some operators, such as &&, ||, ?:, =, and member access operators, cannot be overloaded directly.

            #endregion

            #region genderr

            //Console.WriteLine($"Default enum size: {sizeof(int)} byte");
            //Console.WriteLine($"Byte enum size: {sizeof(byte)} byte");

            //GenderInt g1 = GenderInt.Male;
            //GenderByte g2 = GenderByte.Male;

            //Console.WriteLine(g1);
            //Console.WriteLine(g2);

            //question :
            //When the enum has many values and memory efficiency is important,
            //especially when storing large numbers of enum values.
            //You should choose a type that can safely hold all required values.
            #endregion

            #region utility2
            //double f = Utility.CelsiusToFahrenheit(25);
            //double c = Utility.FahrenheitToCelsius(77);

            //Console.WriteLine($"25 Celsius = {f} Fahrenheit");
            //Console.WriteLine($"77 Fahrenheit = {c} Celsius");

            ////question :
            ////Because a static class cannot be instantiated. Instance constructors are used to initialize objects,
            ////while a static class only contains class-level members. 
            #endregion

            #region GRADES INPUT
            //Console.Write("Enter a grade: ");
            //string input = Console.ReadLine();

            //if (Enum.TryParse(input,true, out Grades grade))
            //{
            //    Console.WriteLine($"Valid grade: {grade}");
            //}
            //else
            //{
            //    Console.WriteLine("Invalid grade.");
            //}

            //QUESTION:
            //Enum.TryParse does not throw an exception when the input is invalid.
            //It returns false, allowing the program to handle invalid input safely.
            #endregion

            #region employee
            //Employee[] employees =
            //{
            //new Employee { Id = 1, Name = "Ahmed" },
            //new Employee { Id = 2, Name = "Mona" },
            //new Employee { Id = 3, Name = "Ali" }
            //};

            //Employee searchEmployee = new Employee
            //{
            //    Id = 2,
            //    Name = "Mona"
            //};

            //int index = Helper2<Employee>.SearchArray(
            //    employees,
            //    searchEmployee
            //);

            //Console.WriteLine($"Index = {index}"); 

            //question : 
            //Equals() can be overridden to define logical/value equality.
            //For classes, == normally checks whether two references refer to the same object unless
            //the operator is overloaded.
            //For structs, Equals() provides value-based comparison by default,
            //while == is not automatically available unless the struct defines/overloads it.

            //question 2:
            //It provides a meaningful string representation of the object instead of the default class name,
            //making debugging, logging, and displaying objects easier.
            #endregion

            #region helper max
            //Console.WriteLine(Helper.Max(10, 20));
            //Console.WriteLine(Helper.Max(5.5, 3.2));
            //Console.WriteLine(Helper.Max("Ahmed", "Mona")); 

            //question :
            //Yes.Generic type parameters can have constraints.
            #endregion

            #region replace array
            //int[] numbers = { 1, 2, 1, 3, 1 };

            //Helper2<int>.replacearr(numbers, 1, 10);

            //foreach (int number in numbers)
            //    Console.Write(number + " ");

            //Console.WriteLine();

            //string[] names = { "Ali", "Ahmed", "Ali", "Mona" };

            //Helper2<string>.replacearr(names, "Ali", "Omar");

            //foreach (string name in names)
            //    Console.Write(name + " "); 

            //question :
            //A generic method has a type parameter for one method.
            //A generic class has a type parameter that can be used by multiple members of the class.
            #endregion

            #region swap
            //rectangle r1 = new rectangle
            //{
            //    h = 10,
            //    w = 5
            //};
            //rectangle r2 = new rectangle
            //{
            //    h = 20,
            //    w = 8
            //};
            //helper.Swap(ref r1, ref r2);

            //Console.WriteLine($"R1: {r1.h}, {r1.w}");
            //Console.WriteLine($"R2: {r2.h}, {r2.w}"); 

            //question :
            //A generic Swap<T> can work with many different types,
            //so we don't need to write a separate swap method for every type.
            #endregion

            #region department
            //Department it = new Department { Name = "IT" };
            //Department hr = new Department { Name = "HR" };

            //employee[] employees =
            //{
            //new employee { Id = 1, Name = "Ahmed", department = it },
            //new employee { Id = 2, Name = "Mona", department = hr },
            //new employee { Id = 3, Name = "Ali", department = it }
            //};

            //int index = Helper2<employee>.SearchArray(
            //    employees,
            //    new employee
            //    {
            //        Id = 3,
            //        Name = "Ali",
            //        department =  it 
            //    });

            //Console.WriteLine($"Employee index = {index}"); 

            //question :
            //It allows two different Department objects to be considered equal when they represent
            //the same department, based on their values rather than their object references.

            #endregion

            #region == opereator
            //CircleStruct s1 = new CircleStruct
            //{
            //    Radius = 5,
            //    Color = "Red"
            //};

            //CircleStruct s2 = new CircleStruct
            //{
            //    Radius = 5,
            //    Color = "Red"
            //};

            //Console.WriteLine(s1 == s2);
            //Console.WriteLine(s1.Equals(s2));

            //CircleClass c1 = new CircleClass
            //{
            //    Radius = 5,
            //    Color = "Red"
            //};

            //CircleClass c2 = new CircleClass
            //{
            //    Radius = 5,
            //    Color = "Red"
            //};

            //Console.WriteLine(c1 == c2);
            //Console.WriteLine(c1.Equals(c2)); 

            //question
            //Because C# does not automatically define an == operator for every user-defined struct.
            //The programmer must overload == and != if that comparison is appropriate for the struct.
            #endregion

            // --------------------------------- part 2 ---------------------------------

            #region reverse array
            //int[] numbers = { 1, 2, 3, 4, 5 };

            //int[] reversedNumbers = reversearray.Revarr(numbers);

            //foreach (int number in reversedNumbers)
            //{
            //    Console.Write(number + " ");
            //}

            //Console.WriteLine();

            //// String array
            //string[] names = { "Ahmed", "Mona", "Ali" };

            //string[] reversedNames = reversearray.Revarr(names);

            //foreach (string name in reversedNames)
            //{
            //    Console.Write(name + " ");
            //} 
            #endregion

            #region stack
            //stack<int> stack = new stack<int>();

            //stack.push(10);
            //stack.push(20);
            //stack.push(30);

            //Console.WriteLine("Top: " + stack.peek());//30

            //Console.WriteLine("Pop: " + stack.pop());//30

            //Console.WriteLine("Top: " + stack.peek());//20 
            #endregion

            #region swap array
            //int[] numbers = { 10, 20, 30, 40 };

            //swapelement<int>.swaparray(numbers, 0, 3);

            //foreach (int number in numbers)
            //{
            //    Console.Write(number + " ");
            //}

            //Console.WriteLine();

            //string[] names = { "Ahmed", "Mona", "Ali" };

            //swapelement<string>.swaparray(names, 0, 2);

            //foreach (string name in names)
            //{
            //    Console.Write(name + " ");
            //} 
            #endregion

            #region max array
            //int[] x = { 1, 2, 3, 4, 5 };

            //Console.WriteLine(maxarray<int>.max(x));
            #endregion



        }
    }
}
