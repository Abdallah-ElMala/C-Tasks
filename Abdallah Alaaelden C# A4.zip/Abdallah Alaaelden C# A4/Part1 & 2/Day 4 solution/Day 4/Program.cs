﻿using System;
using System.Runtime.InteropServices;

namespace Day_4
{
    internal class Program
    {

        enum DayOfWeek
        {
            Saturday = 1,
            Sunday = 2,
            Monday = 3,
            Tuesday = 4,
            Wednesday = 5,
            Thursday = 6,
            Friday = 7
        }


        static void Main(string[] args)
        {
            // -------------------- part 1 --------------------

            #region Problem 1
            ////Problem 1
            //// 1)intialize
            ////1.1
            //int[] arr1 = new int [3];
            //arr1 [0] = 1;
            //arr1 [1] = 2;
            //arr1 [2] = 3;
            //// 1.2
            //int[] arr2 = new int[] { 1, 2, 3 };
            //// 1.3
            //int[] arr3 = { 1, 2, 3 };

            //// 2)Display
            //// 2.1
            //Console.WriteLine("Array 1:");
            //for (int i = 0; i < arr1.Length; i++) 
            //{
            //    Console.WriteLine($"Element {i+1} = {arr1[i]}");
            //}
            //// 2.2
            //Console.WriteLine("Array 2:");
            //for (int i = 0; i < arr2.Length; i++) 
            //{
            //    Console.WriteLine($"Element {i+1} = {arr2[i]}");
            //}
            //// 2.3
            //Console.WriteLine("Array 3:");
            //for (int i = 0; i < arr3.Length; i++) 
            //{
            //    Console.WriteLine($"Element {i+1} = {arr3[i]}");
            //}

            //// 3)Demonstrate
            //// 3.1
            //Console.WriteLine("Demonstrating array");
            //try
            //{
            //    Console.WriteLine(arr1[3]);
            //}
            //catch (IndexOutOfRangeException x)
            //{
            //    Console.WriteLine($"Error: {x.Message}");
            //}
            //// 3.2
            //try
            //{
            //    Console.WriteLine(arr2[3]);
            //}
            //catch (IndexOutOfRangeException x)
            //{
            //    Console.WriteLine($"Error: {x.Message}");
            //}
            //// 3.3
            //try
            //{
            //    Console.WriteLine(arr3[3]);
            //}
            //catch (IndexOutOfRangeException x)
            //{
            //    Console.WriteLine($"Error: {x.Message}");
            //} 
            #endregion

            #region Question 1
            // Question 1 --> What is the default value assigned to array elements in C#? 
            // numeric types (int, float, double, etc.) -> 0
            // reference types (string, class objects, etc.) -> null
            // char types -> '\0' (null)
            // bool types -> false 
            #endregion

            #region Problem 2

            //// Problem 2
            //// shallow copy
            //int[] arr1 = { 1, 2, 3 };
            //int[] arr2 = arr1;
            //Console.WriteLine($"Arr1[0] = {arr1[0]}");
            //arr2[0] = 10;
            //Console.WriteLine($"arr1[0] is now = {arr1[0]}");
            //Console.WriteLine();
            //// deep copy
            //arr2 = (int[])arr1.Clone();
            //Console.WriteLine($"arr1[1] = {arr1[1]}");
            //Console.WriteLine($"arr2[1] = {arr2[1]}");
            //Console.WriteLine($"hashcode arr1 = {arr1.GetHashCode()}");
            //Console.WriteLine($"hashcode arr2 = {arr2.GetHashCode()}"); 
            #endregion

            #region Question 2
            //Question 2 --> What is the difference between Array.Clone() and Array.Copy()? 
            // Array.clone
            // 1. Creates a shallow copy of the array.
            // 2. Returns a new array of the same type and size as the original array
            // 3. Copies the elements of the original array to the new array.
            // Array.Copy
            // 1. Copies a range of elements from one array to another array.
            // 2. Can copy elements from one array to another array of a different type 
            // 3. references the same array in memory, so changes made to one array will affect the other array. 
            #endregion

            #region Problem 3
            //// Problem 3
            //int[,] grades = new int[3, 3];
            ////take input 
            //for (int i = 0; i < grades.GetLength(0); i++)
            //{
            //    Console.WriteLine($"student {i + 1}");
            //    for (int j = 0; j < grades.GetLength(1);)
            //    {
            //        Console.WriteLine($"subject {j + 1}:");
            //        bool flag = int.TryParse(Console.ReadLine(), out grades[i, j]);
            //        if (flag && grades[i, j] >= 0 && grades[i, j] <= 100)
            //            j++;   
            //    }
            //}
            //Console.Clear();
            //// display
            //for (int i = 0; i < grades.GetLength(0); i++)
            //{
            //    Console.WriteLine($"degrees student {i + 1}");
            //    for (int j = 0; j < grades.GetLength(1); j++)
            //    {
            //        Console.WriteLine($"the grade for subject {j + 1}: {grades[i, j]}");
            //    }
            //} 
            #endregion

            #region Question 3
            //Question 3 --> What is the difference between GetLength() and Length for multidimensional arrays? 
            // GetLength() returns the number of elements in a specific dimension of a multidimensional array
            // Length returns the total number of elements in all dimensions of a multidimensional array 
            #endregion

            #region Problem 4
            //// PRoblem 4
            //int[] arr1 = { 1, 3, 2 };
            //int[] arr2 = new int[3];
            //Console.WriteLine("**** After changes ****");
            //Console.WriteLine(arr1[0]);
            //Console.WriteLine(arr1[1]);
            //Console.WriteLine(arr1[2]);

            //Console.WriteLine("**** SORT ****");
            //Array.Sort(arr1);
            //Console.WriteLine(arr1[0]);
            //Console.WriteLine(arr1[1]);
            //Console.WriteLine(arr1[2]);

            //Console.WriteLine("**** REVERSE ****");
            //Array.Reverse(arr1);
            //Console.WriteLine(arr1[0]);
            //Console.WriteLine(arr1[1]);
            //Console.WriteLine(arr1[2]);

            //Console.WriteLine("**** INDEX OF ****");
            //int index = Array.IndexOf(arr1, 3);
            //Console.WriteLine($"index of 3 is {index}");

            //Console.WriteLine("*** COPY ****");
            //Array.Copy(arr1, 0, arr2, 0, 2);
            //Console.WriteLine(arr2[0]);
            //Console.WriteLine(arr2[1]);
            //Console.WriteLine(arr2[2]);

            //Console.WriteLine("**** CLEAR ****");
            //Array.Clear(arr1, 0, arr1.Length);
            //Console.WriteLine(arr1[0]);
            //Console.WriteLine(arr1[1]);
            //Console.WriteLine(arr1[2]); 
            #endregion

            #region Question 4
            // Question 4 -->What is the difference between Array.Copy() and Array.ConstrainedCopy() ?
            // Array.Copy() copies a range of elements from one array to another array, and it does not check for overlapping ranges.
            // Array.ConstrainedCopy() copies a range of elements from one array to another array, and it checks for overlapping ranges.
            // If the source and destination ranges overlap, it throws an exception.
            // Array.ConstrainedCopy() is more efficient than Array.Copy() because it does not create a temporary array to hold the copied elements. 
            #endregion

            #region Problem 5
            // Problem 5
            //int[] arr1 = { 1, 2, 3, 4 };
            //Console.WriteLine("**** for loop ****");
            //for (int i = 0; i < arr1.Length; i++)
            //{
            //    Console.WriteLine(arr1[i]);
            //}

            //Console.WriteLine("**** foreach loop ****");
            //foreach (int i in arr1)
            //{
            //    Console.WriteLine(i);
            //}

            //Console.WriteLine("**** while loop ****");
            //int index = arr1.Length - 1;
            //while (index >= 0)
            //{
            //    Console.WriteLine(arr1[index]);
            //    index--;
            //} 
            #endregion

            #region Question 5
            // Question 5 --> Why is foreach preferred for read-only operations on arrays? 
            // 1. It provides a simpler and more concise syntax for iterating over the elements of an array.
            // 2. It eliminates the need for manual index management, reducing the risk of errors such as off-by-one mistakes.
            // 3. It enhances code readability, making it easier to understand the intent of the loop.
            // 4. It prevents accidental modification of the array elements, as the loop variable is read-only within the foreach construct. 
            #endregion

            #region Problem 6
            //// Problem 6 
            //int odd;
            //bool flag;
            //do
            //{
            //    Console.Write("enter a valid odd number : ");
            //    flag = int.TryParse(Console.ReadLine(), out odd);
            //    if (odd % 2 == 0)
            //    {
            //        Console.WriteLine("number must be odd ");
            //        flag = false;
            //    }
            //    if (odd < 0)
            //    {
            //        Console.Write ("Number must be positive : ");
            //        flag = false;
            //    }

            //}
            //while (!flag);

            //Console.WriteLine($"valid number : {odd}"); 
            #endregion

            #region Question 6
            // Question 6 --> Why is input validation important when working with user inputs?
            // Crash Prevention -> Prevents runtime exceptions and application crashes (Defensive Programming)
            // Data Integrity -> Ensures that processed data strictly adheres to business logic constraints
            // User Experience -> Provides clear error messages and allows users to re-enter valid data 
            #endregion

            #region Problem 7
            // Problem 7
            //int[,] arr1 = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
            //for (int row = 0; row < arr1.GetLength(0); row++)
            //{
            //    for (int col = 0; col < arr1.GetLength(1); col++)
            //       { Console.Write($"{arr1[row, col],5}");
            //         Console.WriteLine(); }
            //} 
            #endregion

            #region Question 7
            // Question 7 --> How can you format the output of a 2D array for better readability?
            // Spacing -> Use tab characters ('\t') or alignment specifiers in string interpolation (e.g., {val, 4})
            // Structure -> Print inner loop elements with Console.Write() and add Console.WriteLine() after each row
            // Visual Separation -> Use borders or clear headers to align columns cleanly 
            #endregion

            #region Problem 8
            //// Problem 8
            //Console.Write("Enter Month Number: ");
            //int.TryParse(Console.ReadLine(), out int month);

            //// Using if and else
            //if (month == 1)
            //    Console.WriteLine("January");
            //else if (month == 2)
            //    Console.WriteLine("February");
            //else if (month == 3)
            //    Console.WriteLine("March");
            //else if (month == 4)
            //    Console.WriteLine("April");
            //else if (month == 5)
            //    Console.WriteLine("May");
            //else if (month == 6)
            //    Console.WriteLine("June");
            //else if (month == 7)
            //    Console.WriteLine("July");
            //else if (month == 8)
            //    Console.WriteLine("August");
            //else if (month == 9)
            //    Console.WriteLine("September");
            //else if (month == 10)
            //    Console.WriteLine("October");
            //else if (month == 11)
            //    Console.WriteLine("November");
            //else if (month == 12)
            //    Console.WriteLine("December");
            //else
            //    Console.WriteLine("Invalid month");

            ////using switch
            //switch (month)
            //{
            //    case 1:
            //        Console.WriteLine("January");
            //        break;

            //    case 2:
            //        Console.WriteLine("February");
            //        break;

            //    case 3:
            //        Console.WriteLine("March");
            //        break;

            //    case 4:
            //        Console.WriteLine("April");
            //        break;

            //    case 5:
            //        Console.WriteLine("May");
            //        break;

            //    case 6:
            //        Console.WriteLine("June");
            //        break;

            //    case 7:
            //        Console.WriteLine("July");
            //        break;

            //    case 8:
            //        Console.WriteLine("August");
            //        break;

            //    case 9:
            //        Console.WriteLine("September");
            //        break;

            //    case 10:
            //        Console.WriteLine("October");
            //        break;

            //    case 11:
            //        Console.WriteLine("November");
            //        break;

            //    case 12:
            //        Console.WriteLine("December");
            //        break;

            //    default:
            //        Console.WriteLine("Invalid month");
            //        break;
            //} 
            #endregion

            #region Question 8
            // Question 8 --> When should you prefer a switch statement over if-else?
            // Discrete Values -> Evaluating a single variable against multiple exact constant values
            // Code Readability -> Replaces long, messy if-else-if chains with clean control blocks
            // Optimization -> Compiler can optimize switch statements using jump tables for faster execution

            #endregion

            #region Problem 9
            // Problem 9
            //int[] arr1 = { 5, 4, 6, 7, 3, 2, 7 };
            //Array.Sort(arr1);
            //Console.WriteLine(" array are sorted");
            //for (int i = 0; i < arr1.Length; i++)
            //    Console.WriteLine(arr1[i]);

            //int x = Array.IndexOf(arr1, 7);
            //int y = Array.LastIndexOf(arr1, 7);

            //Console.WriteLine("**** index of ****");
            //Console.WriteLine(x);
            //Console.WriteLine("**** Last index of ****");
            //Console.WriteLine(y); 
            #endregion

            #region Question 9
            // Question 9 --> What is the time complexity of Array.Sort()?
            // Average Case -> O(N log N), where N is the total number of elements
            // Worst Case   -> O(N log N), guaranteed by using IntroSort algorithm (QuickSort + HeapSort + InsertionSort)
            // Space Complexity -> O(log N) auxiliary space allocation 
            #endregion

            #region Problem 10
            //// Problem 10
            //int[] arr1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            //int sum = 0;
            //Console.WriteLine("using for loop");
            //for (int i = 0; i < arr1.Length; i++)
            //    sum += arr1[i];

            //Console.WriteLine($"Sum = {sum}");
            //Console.WriteLine();
            //int sum1 = 0;
            //Console.WriteLine("using foreach loop");
            //foreach (int i in arr1)
            //{
            //    sum1 += i;
            //}
            //Console.WriteLine($"Sum = {sum1}"); 
            #endregion

            #region Question 10
            // Question 10 --> Which loop (for or foreach) is more efficient for calculating the sum of an array, and why?
            // 'for' loop -> Slightly faster due to direct index access without object instantiation overhead
            // 'foreach' loop -> Incurs minor performance overhead from GetEnumerator call and state management
            // Practical Impact -> Performance difference is negligible in modern .NET for standard arrays 
            #endregion

            // -------------------- part 2 --------------------

            #region Part 2 
            //// problem 2
            //Console.Write("Enter a number from 1 to 7: ");
            //int.TryParse(Console.ReadLine(), out int number);

            //DayOfWeek day = (DayOfWeek)Enum.Parse(typeof(DayOfWeek), number.ToString());

            //Console.WriteLine($"Day: {day}");

            //// Question 3 --> What happens if the user enters a value outside the range of 1 to 7?
            //// Number out of range (e.g., 10) -> Enum.Parse prints "10" without crashing
            //// Non-number text (e.g., "abc") -> Enum.Parse crashes with a FormatException 
            #endregion

        }
    }
}
