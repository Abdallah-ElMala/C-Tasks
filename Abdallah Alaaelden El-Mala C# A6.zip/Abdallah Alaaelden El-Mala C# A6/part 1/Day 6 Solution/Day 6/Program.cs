﻿using System;

namespace Day_6
{
    #region Point 
    public struct Point
    {
        private int X { get; set; }
        private int Y { get; set; }

        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }
        public override string ToString()
        {
            return $"({X}, {Y})";
        }
    }
    #endregion

    #region TypeA
    public class TypeA
    {
        private int F = 10;
        internal int G = 20;
        public int H = 30;

        public void PrintPrivate()
        {
            Console.WriteLine($"Private F: {F}");
        }
    }
    #endregion

    #region Employee
    public struct Employee
    {
        private int empId;
        private string name;
        private decimal salary;

        public Employee(int empId, string name, decimal salary)
        {
            this.empId = empId;
            this.name = name;
            this.salary = salary;
        }

        public string GetName() => name;
        public void SetName(string name) => this.name = name;

        public int EmpId
        {
            get => empId;
            set => empId = value;
        }

        public decimal Salary
        {
            get => salary;
            set => salary = value > 0 ? value : 0;
        }
    }
    #endregion

    #region Point2
    public struct Point2
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Point2(int x)
        {
            X = x;
            Y = 0;
        }

        public Point2(int x, int y)
        {
            X = x;
            Y = y;
        }
    } 
    #endregion



    internal class Program
    {
        static void Main(string[] args)
        {
            // ------------------------------------ Part 1 ------------------------------------

            #region Problem 1
            //// problem 1
            //Point p1 = new Point(); 
            //Point p2 = new Point(10, 20); 
            //Console.WriteLine(p1); 
            //Console.WriteLine(p2);  

            //// Question: Why can't a struct inherit from another struct or class in C#?
            //// Answer: In C#, structs are value types and do not support inheritance
            //// because they are designed to be lightweight and efficient.
            //// They cannot have a base class or derive from another struct or class.
            //// This is because structs are intended to be used for small, simple data structures
            //// and allowing inheritance would introduce additional complexity and overhead.
            #endregion

            #region Problem 2
            //// Problem 2
            //TypeA obj = new TypeA();
            //Console.WriteLine($"Internal G: {obj.G}"); 
            //Console.WriteLine($"Public H: {obj.H}");    
            //obj.PrintPrivate(); 

            //// Question: How do access modifiers impact the scope and visibility of a class member? 
            //// Access modifiers determine the accessibility of class members (fields, properties, methods) in C#.
            //// They define the level of access that other classes or code have to those members.
            //// For example, private members are only accessible within the same class, while public members can be accessed from anywhere.
            #endregion

            #region Problem 3
            //// Problem 3
            //Employee emp = new Employee(101, "Alice", 50000);
            //emp.SetName("Alice Smith");
            //emp.Salary = 55000;
            //Console.WriteLine($"ID: {emp.EmpId}, Name: {emp.GetName()}, Salary: {emp.Salary:C}");

            //// Question: Why is encapsulation critical in software design? 
            //// Encapsulation is critical in software design because it helps to protect the internal state of an object
            //// and ensures that it can only be modified through well-defined interfaces (methods or properties).
            //// This promotes data integrity, reduces the risk of unintended side effects, and makes the code easier to maintain and understand. 
            #endregion

            #region Problem 4
            //// Problem 4
            //Point2 p1 = new Point2(5);
            //Point2 p2 = new Point2(10, 20);
            //Console.WriteLine($"P1: ({p1.X}, {p1.Y})"); 
            //Console.WriteLine($"P2: ({p2.X}, {p2.Y})");

            //// Question: Question: what is constructors in structs?
            //// Constructors in structs are special methods that are used to initialize the fields of a struct when it is created.
            //// They allow you to set initial values for the struct's properties or fields, and they can be overloaded to provide different ways of initializing the struct.
            //// Struct constructors must initialize all fields of the struct, and they cannot have a parameterless constructor.
            //// Structs are value types, so when you create a new instance of a struct, the constructor is called to set up the initial state of that instance. 
            #endregion

            #region Problem 5
            //// Problem 5
            //Point[] points = { new Point(1, 2), new Point(3, 4), new Point(5, 6) };
            //foreach (var p in points)
            //{
            //    Console.WriteLine(p);
            //}
            //// Question: How does overriding methods like ToString() improve code readability? 
            //// Overriding methods like ToString() improves code readability by providing a meaningful string representation of an object.
            //// This allows developers to easily understand the state of an object when it is printed or logged, rather than seeing a default representation.
            //// It enhances debugging and logging, making it easier to track the flow of data and identify issues in the code. 
            #endregion


        }
    }
}
