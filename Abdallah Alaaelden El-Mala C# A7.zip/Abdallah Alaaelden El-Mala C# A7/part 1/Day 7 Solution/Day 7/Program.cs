﻿using System;

namespace Day_7
{


    #region Car (Problem 1)
    internal class car
    {
        #region Attributes
        private int id;
        private string brand;
        private decimal price;
        #endregion

        #region Properties
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Brand
        {
            get { return brand; }
            set { brand = value; }
        }
        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }
        #endregion

        #region ctor
        public car() : this(0, "Unknown", 0.0m) { }
        public car(int Id) : this(Id, "Unknown", 0.0m) { }
        public car(int Id, string Brand) : this(Id, Brand, 0.0m) { }
        public car(int Id, string Brand, decimal Price)
        {
            this.id = Id;
            this.brand = Brand;
            this.price = Price;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return $"ID: {Id}, Brand: {Brand}, Price: ${Price}";
        }
        #endregion
    }
    #endregion

    #region Calculator (Problem 2)
    internal class Calculator
    {
        #region Overloaded Methods
        public int Sum(int a, int b)
        {
            return a + b;
        }
        public int Sum(int a, int b, int c)
        {
            return a + b + c;
        }
        public double Sum(double a, double b)
        {
            return a + b;
        }
        #endregion
    }
    #endregion

    #region Parent & Child Classes (Problems 3, 4, 5)
    internal class Parent
    {
        #region Properties
        public int X { get; set; }
        public int Y { get; set; }
        #endregion

        #region Constructor
        public Parent(int x, int y)
        {
            X = x;
            Y = y;
        }
        #endregion

        #region Methods
        public virtual int Product()
        {
            return X * Y;
        }

        public override string ToString()
        {
            return $"({X}, {Y})";
        }
        #endregion
    }

    internal class Child : Parent
    {
        #region Properties
        public int Z { get; set; }
        #endregion

        #region Constructor
        public Child(int x, int y, int z) : base(x, y)
        {
            Z = z;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return $"({X}, {Y}, {Z})";
        }
        #endregion
    }

    internal class ChildNew : Parent
    {
        public int Z { get; set; }

        public ChildNew(int x, int y, int z) : base(x, y)
        {
            Z = z;
        }

        public new int Product()
        {
            return X * Y * Z;
        }
    }

    internal class ChildOverride : Parent
    {
        public int Z { get; set; }

        public ChildOverride(int x, int y, int z) : base(x, y)
        {
            Z = z;
        }

        public override int Product()
        {
            return X * Y * Z;
        }
    }
    #endregion

    #region IShape & Rectangle & Circle (Problems 6 & 7)
    public interface IShape
    {
        double Area { get; }
        void Draw();

        // Default Implementation introduced in C# 8.0
        public void PrintDetails()
        {
            Console.WriteLine($"[Default Interface Method] Area: {Area}");
        }
    }

    public class Rectangle : IShape
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }

        public double Area => Width * Height;

        public void Draw()
        {
            Console.WriteLine($"Drawing Rectangle with Width: {Width} and Height: {Height}");
        }
    }

    public class Circle : IShape
    {
        public double Radius { get; set; }

        public Circle(double radius)
        {
            Radius = radius;
        }

        public double Area => Math.PI * Radius * Radius;

        public void Draw()
        {
            Console.WriteLine($"Drawing Circle with Radius: {Radius}");
        }
    }
    #endregion

    #region IMovable & Car (Problem 8)
    public interface IMovable
    {
        void Move();
    }

    public class CarMovable : IMovable
    {
        public void Move()
        {
            Console.WriteLine("Car is moving on the road...");
        }
    }
    #endregion

    #region Multiple Interfaces (Problem 9)
    public interface IReadable
    {
        void Read();
    }

    public interface IWritable
    {
        void Write();
    }

    public class File : IReadable, IWritable
    {
        public void Read()
        {
            Console.WriteLine("Reading data from file...");
        }

        public void Write()
        {
            Console.WriteLine("Writing data to file...");
        }
    }
    #endregion

    #region Abstract Class Shape (Problem 10)
    public abstract class Shape
    {
        public virtual void Draw()
        {
            Console.WriteLine("Drawing Shape");
        }

        public abstract double CalculateArea();
    }

    public class AbstractRectangle : Shape
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public AbstractRectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }

        public override void Draw()
        {
            Console.WriteLine($"Drawing Abstract Rectangle ({Width} x {Height})");
        }

        public override double CalculateArea()
        {
            return Width * Height;
        }
    }
    #endregion

    internal class Program
    {
        static void Main(string[] args)
        {
            // ---------------------------------------------- Part 01 ----------------------------------------------

            #region Problem 1
            //car car1 = new car();
            //car car2 = new car(102);
            //car car3 = new car(103, "Toyota");
            //car car4 = new car(104, "BMW", 5000000.00m);
            //Console.WriteLine($"car1: {car1}");
            //Console.WriteLine($"car2: {car2}");
            //Console.WriteLine($"car3: {car3}");
            //Console.WriteLine($"car4: {car4}");

            //// Question: Why does defining a custom constructor suppress the default constructor in C#? 

            //// 1. Safety and Control: Defining a custom constructor signals that the developer wants
            ////    strict control over how the object is initialized.
            //// 2. Preventing Invalid States: Automatically generating an uninitialized parameterless 
            ////    constructor could allow creation of objects in an incomplete or invalid state.
            //// 3. Compiler Behavior: The compiler only provides a parameterless constructor when NO 
            ////    constructors are defined; defining any custom constructor overrides this default behavior.
            #endregion

            #region Problem 2
            //Calculator calc = new Calculator();

            //int sum2Int = calc.Sum(10, 20);
            //Console.WriteLine($" 10 + 20 = {sum2Int}");

            //int sum3Int = calc.Sum(5, 15, 25);
            //Console.WriteLine($" 5 + 15 + 25 = {sum3Int}");

            //double sum2Doubles = calc.Sum(10.5, 20.3);
            //Console.WriteLine($" 10.5 + 20.3 = {sum2Doubles}");

            //// Question: How does method overloading improve code readability and reusability?

            //// 1. Readability: Allows developers to use a single intuitive method name (e.g., Sum) 
            ////    for operations that perform the same conceptual action on different data types.
            //// 2. Consistency: Eliminates the need to memorize distinct method names like SumInt, 
            ////    SumDouble, or SumThreeInts.
            //// 3. Reusability: Provides flexibility for caller code to pass various argument types 
            ////    and counts seamlessly.
            //// 4. Clean Code: Groups related business logic together under a single cohesive class API.
            #endregion

            #region Problem 3
            //Child childObj = new Child(10, 20, 30);
            //Console.WriteLine($"Child Instance -> X: {childObj.X}, Y: {childObj.Y}, Z: {childObj.Z}");

            //// Question: What is the purpose of constructor chaining in inheritance?

            //// 1. Code Reusability: Reuses the initialization logic already written in the base class 
            ////    constructor using the 'base' keyword.
            //// 2. Proper Order of Initialization: Ensures that base class members are fully initialized 
            ////    before derived class members are set up.
            //// 3. Maintainability: Avoids duplicating assignment code for inherited fields/properties 
            ////    in derived class constructors.
            //// 4. Clean Code: Keeps derived class constructors concise and focused only on their own 
            ////    specific properties.
            #endregion

            #region Problem 4
            //Parent p1 = new ChildNew(2, 3, 4);
            //Console.WriteLine($"With 'new' (Parent Reference): Product = {p1.Product()}");

            //ChildNew c1 = new ChildNew(2, 3, 4);
            //Console.WriteLine($"With 'new' (Child Reference): Product = {c1.Product()}");

            //Parent p2 = new ChildOverride(2, 3, 4);
            //Console.WriteLine($"With 'override' (Parent Reference): Product = {p2.Product()}");

            //// Question: How does new differ from override in method overriding?

            //// 1. Binding Type: 'override' uses dynamic/late binding (evaluated at runtime), while 
            ////    'new' uses static/early binding (evaluated at compile time).
            //// 2. Reference Type vs Object Type: With 'override', calling the method through a parent 
            ////    reference executes the derived class version. With 'new', it executes the parent version.
            //// 3. Virtual Table (V-Table): 'override' modifies the existing v-table entry, whereas 
            ////    'new' creates an entirely separate method entry and hides the base method.
            //// 4. Requirement: 'override' requires the base method to be marked 'virtual' or 'abstract', 
            ////    while 'new' can shadow any inherited method without virtual modifiers.
            #endregion

            #region Problem 5
            //Parent parentInstance = new Parent(10, 20);
            //Child childInstance = new Child(5, 15, 25);

            //Console.WriteLine($"Parent ToString(): {parentInstance}");
            //Console.WriteLine($"Child ToString(): {childInstance}");

            //// Question: Why is ToString() often overridden in custom classes?

            //// 1. Meaningful Text Representation: By default, ToString() returns the fully qualified class name. 
            ////    Overriding it provides clear textual representations of object values.
            //// 2. Easy Debugging and Logging: Helps print object details directly using Console.WriteLine(obj).
            //// 3. Clean Code: Avoids manual property formatting repeatedly across the application.
            #endregion

            #region Problem 6
            //IShape rectShape = new Rectangle(5.0, 4.0);
            //rectShape.Draw();
            //Console.WriteLine($"Rectangle Area: {rectShape.Area}");

            //// Question: Why can't you create an instance of an interface directly?

            //// 1. Unimplemented Contract: Interfaces contain method declarations without full memory allocation 
            ////    or executable body implementations.
            //// 2. Abstract Definition: An interface is a pure contract, not a concrete object blueprint.
            //// 3. Compiler Safety: Prevents runtime errors from attempting to invoke methods with no body.
            #endregion

            #region Problem 7
            //IShape circleShape = new Circle(7.0);
            //circleShape.Draw();
            //Console.WriteLine($"Circle Area: {circleShape.Area:F2}");

            //circleShape.PrintDetails();

            //// Question: What are the benefits of default implementations in interfaces introduced in C# 8.0?

            //// 1. Backward Compatibility: Allows adding new capabilities to an existing interface 
            ////    without breaking legacy classes implementing it.
            //// 2. Avoids Code Duplication: Shares default utility logic across all implementing classes.
            //// 3. Flexibility: Classes can optionally override default implementations if custom behavior is needed.
            #endregion

            #region Problem 8
            //IMovable movableCar = new CarMovable();
            //movableCar.Move();

            //// Question: Why is it useful to use an interface reference to access implementing class methods?

            //// 1. Decoupling & Flexibility: Hides concrete implementation details, exposing only the contract.
            //// 2. Polymorphism & Swapability: Allows switching implementation classes dynamically without changing client code.
            //// 3. Dependecy Inversion: Promotes programming to an interface rather than a concrete implementation.
            #endregion

            #region Problem 9
            //File fileObj = new File();

            //fileObj.Read();
            //fileObj.Write();

            //IReadable reader = fileObj;
            //reader.Read();

            //IWritable writer = fileObj;
            //writer.Write();

            //// Question: How does C# overcome the limitation of single inheritance with interfaces?

            //// 1. Multiple Interface Implementation: C# allows a single class to implement multiple interfaces simultaneously.
            //// 2. Avoiding Diamond Problem: Interfaces declare behavioral contracts without direct state inheritance, 
            ////    preventing state conflict issues common in multiple class inheritance.
            #endregion

            #region Problem 10
            //Shape shapeRef = new AbstractRectangle(10.0, 5.0);
            //shapeRef.Draw();
            //Console.WriteLine($"Calculated Area: {shapeRef.CalculateArea()}");

            //// Question: What is the difference between a virtual method and an abstract method in C#?

            //// 1. Implementation: A 'virtual' method MUST have a default implementation body in the base class. 
            ////    An 'abstract' method has NO body in the base class.
            //// 2. Overriding: Overriding a 'virtual' method is OPTIONAL in derived classes. 
            ////    Overriding an 'abstract' method is MANDATORY in non-abstract derived classes.
            //// 3. Class Type: 'virtual' methods can exist in normal or abstract classes. 
            ////    'abstract' methods can ONLY exist inside abstract classes.
            #endregion
        }
    }
}