﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Day_10
{
    // --------------------------------- part 1 --------------------------------
    #region Delegates 
    public delegate string StringTransformer(string input);
    public delegate int MathOperation(int a, int b);
    public delegate R Transformer<T, R>(T input);
    #endregion

    #region Employee Class
    public class Employee : IComparable<Employee>
    {
        public string Name { get; set; }
        public decimal Salary { get; set; }

        public Employee(string name, decimal salary)
        {
            Name = name;
            Salary = salary;
        }

        public int CompareTo(Employee other)
        {
            if (other == null) return 1;
            return Salary.CompareTo(other.Salary);
        }

        public override string ToString() => $"{Name} - ${Salary}";
    }
    #endregion

    #region Manager Class
    public class Manager : Employee, IComparable<Manager>
    {
        public string Department { get; set; }

        public Manager(string name, decimal salary, string department)
            : base(name, salary)
        {
            Department = department;
        }

        public int CompareTo(Manager other)
        {
            if (other == null) return 1;
            return Salary.CompareTo(other.Salary);
        }

        public override string ToString() => $"{Name} ({Department}) - ${Salary}";
    }
    #endregion

    #region SortingAlgorithm<T> Class
    public class SortingAlgorithm<T> where T : IComparable<T>
    {
        public static void Sort(T[] array)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                for (int j = 0; j < array.Length - i - 1; j++)
                {
                    if (array[j].CompareTo(array[j + 1]) > 0)
                    {
                        Swap(ref array[j], ref array[j + 1]);
                    }
                }
            }
        }

        public static void Swap<TElement>(ref TElement a, ref TElement b)
        {
            TElement temp = a;
            a = b;
            b = temp;
        }
    }
    #endregion

    #region SortingAlgorithmWithConstraint<T> Class
    public class SortingAlgorithmWithConstraint<T> where T : IComparable<T>, ICloneable
    {
        public static T[] CloneAndSort(T[] array)
        {
            T[] clonedArray = new T[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                clonedArray[i] = (T)array[i].Clone();
            }
            SortingAlgorithm<T>.Sort(clonedArray);
            return clonedArray;
        }
    }
    #endregion

    #region SortingTwo<T> Class
    public class SortingTwo<T>
    {
        public static void Sort(T[] array, Func<T, T, bool> compare)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                for (int j = 0; j < array.Length - i - 1; j++)
                {
                    if (compare(array[j], array[j + 1]))
                    {
                        T temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }
        }
    }
    #endregion

    #region Functional Helpers
    public static class FunctionalHelpers
    {
        public static T GetDefault<T>()
        {
            return default(T);
        }

        public static List<string> TransformStrings(List<string> list, StringTransformer transformer)
        {
            List<string> result = new List<string>();
            foreach (var item in list)
            {
                result.Add(transformer(item));
            }
            return result;
        }

        public static int ExecuteOperation(int a, int b, MathOperation operation)
        {
            return operation(a, b);
        }

        public static List<R> Map<T, R>(List<T> list, Transformer<T, R> transformer)
        {
            List<R> result = new List<R>();
            foreach (var item in list)
            {
                result.Add(transformer(item));
            }
            return result;
        }

        public static List<TResult> Transform<T, TResult>(List<T> list, Func<T, TResult> func)
        {
            List<TResult> result = new List<TResult>();
            foreach (var item in list)
            {
                result.Add(func(item));
            }
            return result;
        }

        public static void ProcessList<T>(List<T> list, Action<T> action)
        {
            foreach (var item in list)
            {
                action(item);
            }
        }

        public static List<T> Filter<T>(List<T> list, Predicate<T> predicate)
        {
            List<T> result = new List<T>();
            foreach (var item in list)
            {
                if (predicate(item))
                {
                    result.Add(item);
                }
            }
            return result;
        }

        public static int Calculate(int a, int b, Func<int, int, int> operation) => operation(a, b);

        public static double ExecuteMath(double x, double y, Func<double, double, double> op) => op(x, y);
    }
    #endregion


    public class Program
    {
        public static void Main(string[] args)
        {
            // --------------------------------- part 1 --------------------------------
            #region Problem 1
            Employee[] employees1 = {
                new Employee("Alice", 75000),
                new Employee("Bob", 50000),
                new Employee("Charlie", 60000)
            };
            SortingAlgorithm<Employee>.Sort(employees1);
            Console.WriteLine("--- Problem 01 ---");
            foreach (var emp in employees1) Console.WriteLine(emp);

            // Question: What are the primary advantages of implementing generic sorting with IComparable<T>?
            // 1. Provides compile-time type safety without runtime casting.
            // 2. Eliminates performance overhead caused by boxing and unboxing value types.
            // 3. Enables code reusability across any custom data type implementing IComparable<T>.
            // 4. Enforces a clear contracts for natural sorting across classes.
            // Answer: Generics provide type safety, prevent boxing overhead, and maximize code reuse.

            #endregion

            #region Problem 2

            int[] numbers2 = { 5, 2, 8, 1, 9 };
            SortingTwo<int>.Sort(numbers2, (a, b) => a < b);
            Console.WriteLine("\n--- Problem 02 ---");
            Console.WriteLine(string.Join(", ", numbers2));

            // Question: How do lambda expressions enhance generic dynamic sorting mechanisms?
            // 1. Eliminates the need to declare extra helper methods.
            // 2. Inlines comparison logic directly at the calling site.
            // 3. Dynamically changes sort direction (ascending vs descending) without modifying sorting logic.
            // 4. Improves overall code readability and maintainability.
            // Answer: Lambdas inline flexible comparison rules without extra method overhead.

            #endregion

            #region Problem 3

            string[] words3 = { "Apple", "Kiwi", "Banana", "Fig" };
            SortingTwo<string>.Sort(words3, (s1, s2) => s1.Length > s2.Length);
            Console.WriteLine("\n--- Problem 03 ---");
            Console.WriteLine(string.Join(", ", words3));

            // Question: Why is passing dynamic comparers ideal for string operations?
            // 1. Decouples sorting logic from string comparison rules.
            // 2. Allows sorting by custom criteria such as string length, alphabetical order, or character counts.
            // 3. Avoids modifying the underlying String class.
            // 4. Provides flexible reuse across different string sorting requirements.
            // Answer: Dynamic comparers decouple execution algorithms from custom evaluation rules.

            #endregion

            #region Problem 4

            Manager[] managers4 = {
                new Manager("Dave", 90000, "IT"),
                new Manager("Eve", 110000, "HR"),
                new Manager("Frank", 85000, "Finance")
            };
            SortingAlgorithm<Manager>.Sort(managers4);
            Console.WriteLine("\n--- Problem 04 ---");
            foreach (var mgr in managers4) Console.WriteLine(mgr);

            // Question: Why implement IComparable<T> in derived classes such as Manager?
            // 1. Establishes explicit domain-specific comparison rules for subclass instances.
            // 2. Integrates cleanly with generic algorithms expecting specific generic contracts.
            // 3. Preserves baseline parent class attributes while defining precise class sorting semantics.
            // 4. Prevents reliance on object non-generic comparisons.
            // Answer: It defines explicit natural ordering for domain models used in generic structures.

            #endregion

            #region Problem 5

            Func<Employee, Employee, bool> compareByNameLength = (e1, e2) => e1.Name.Length > e2.Name.Length;
            Employee[] employees5 = {
                new Employee("Alexander", 50000),
                new Employee("Bob", 70000),
                new Employee("Charlie", 60000)
            };
            SortingTwo<Employee>.Sort(employees5, compareByNameLength);
            Console.WriteLine("\n--- Problem 05 ---");
            foreach (var emp in employees5) Console.WriteLine(emp);

            // Question: What advantage does Func<T1, T2, TResult> offer over custom delegate declarations?
            // 1. Standardizes delegate functional signatures across C# libraries.
            // 2. Eliminates boilerplate code required for declaring named custom delegate types.
            // 3. Enhances interoperability with LINQ and generic methods.
            // 4. Reduces namespace clutter.
            // Answer: Func minimizes boilerplate and standardizes generic dynamic signatures.


            #endregion

            #region Problem 6

            int[] numbers6A = { 4, 1, 3, 2 };
            int[] numbers6B = { 4, 1, 3, 2 };

            SortingTwo<int>.Sort(numbers6A, delegate (int a, int b) { return a > b; });
            SortingTwo<int>.Sort(numbers6B, (a, b) => a > b);

            Console.WriteLine("\n--- Problem 06 ---");
            Console.WriteLine("Anonymous: " + string.Join(", ", numbers6A));
            Console.WriteLine("Lambda:    " + string.Join(", ", numbers6B));

            // Question: How do anonymous functions compare with lambda expressions?
            // 1. Both generate identical CIL delegate code under the compiler hood.
            // 2. Anonymous functions use explicit syntax: delegate(params) { return expr; }.
            // 3. Lambda expressions use concise syntax: (params) => expr.
            // 4. Lambdas significantly reduce code verbosity without performance penalty.
            // Answer: Both offer identical execution performance, but lambdas deliver cleaner syntax.

            #endregion

            #region Problem 7

            int x7 = 10, y7 = 20;
            SortingAlgorithm<int>.Swap(ref x7, ref y7);
            Console.WriteLine("\n--- Problem 07 ---");
            Console.WriteLine($"Swapped: x = {x7}, y = {y7}");

            // Question: What are the benefits of writing a generic Swap<T> utility method?
            // 1. Operates on value and reference types seamlessly using reference passing (ref).
            // 2. Guarantees compile-time type safety for swapped operands.
            // 3. Prevents runtime memory allocation and boxing overhead.
            // 4. Provides reusable memory swap logic across all data structures.
            // Answer: Generic swap ensures type safety, zero memory allocation, and high performance.

            #endregion

            #region Problem 8

            Employee[] employees8 = {
                new Employee("Charlie", 50000),
                new Employee("Alice", 50000),
                new Employee("Bob", 70000)
            };

            SortingTwo<Employee>.Sort(employees8, (e1, e2) =>
            {
                if (e1.Salary != e2.Salary)
                    return e1.Salary > e2.Salary;
                return string.Compare(e1.Name, e2.Name) > 0;
            });

            Console.WriteLine("\n--- Problem 08 ---");
            foreach (var emp in employees8) Console.WriteLine(emp);

            // Question: How is multi-criteria sorting handled using dynamic lambdas?
            // 1. Evaluates primary field conditions first.
            // 2. Falls back to secondary criteria when primary field values match.
            // 3. Prevents secondary comparison execution when primary criteria differ.
            // 4. Enables precise multi-field tie-breaking logic.
            // Answer: Tie-breaking comparison branches manage multi-field ordering smoothly.

            #endregion

            #region Problem 9
            int defaultInt = FunctionalHelpers.GetDefault<int>();
            string defaultString = FunctionalHelpers.GetDefault<string>();

            Console.WriteLine("\n--- Problem 09 ---");
            Console.WriteLine($"Default Int: {defaultInt}");
            Console.WriteLine($"Default String: {(defaultString == null ? "null" : defaultString)}");

            // Question: What is the behavior of default(T) across C# data types?
            // 1. Evaluates to null for reference types.
            // 2. Evaluates to 0 for numeric value types.
            // 3. Evaluates to false for boolean types.
            // 4. Zero-initializes all underlying fields for struct types.
            // Answer: Returns null for reference types and zeroed memory representation for value types.


            #endregion

            #region Problem 10

            Console.WriteLine("\n--- Problem 10 ---");
            Console.WriteLine("Multi-constraint class 'SortingAlgorithmWithConstraint' compiled successfully.");

            // Question: What is the purpose of multi-constraint generics like where T : IComparable<T>, ICloneable?
            // 1. Restricts target types to those implementing all specified interfaces.
            // 2. Enables access to members of both interfaces safely at compile time.
            // 3. Eliminates unsafe runtime casting operations like (ICloneable)item.
            // 4. Guarantees that objects can be safely cloned before executing sort operations.
            // Answer: Constraints enforce required instance capabilities at compile time without casting.

            #endregion

            #region Problem 11
            List<string> words11 = new List<string> { "hello", "world" };
            List<string> upper11 = FunctionalHelpers.TransformStrings(words11, s => s.ToUpper());
            List<string> reversed11 = FunctionalHelpers.TransformStrings(words11, s => new string(s.Reverse().ToArray()));

            Console.WriteLine("\n--- Problem 11 ---");
            Console.WriteLine("Upper: " + string.Join(", ", upper11));
            Console.WriteLine("Reversed: " + string.Join(", ", reversed11));

            // Question: How do custom delegates facilitate functional string transformation pipelines?
            // 1. Decouples processing algorithms from specific string modification rules.
            // 2. Allows passing custom logic (e.g. uppercase, reversal) dynamically.
            // 3. Supports clean functional transformation over collections.
            // 4. Enhances modularity and testing isolation.
            // Answer: Delegates treat functions as first-class parameters for dynamic data transformation.

            #endregion

            #region Problem 12
            
            int sum12 = FunctionalHelpers.ExecuteOperation(10, 5, (a, b) => a + b);
            int product12 = FunctionalHelpers.ExecuteOperation(10, 5, (a, b) => a * b);

            Console.WriteLine("\n--- Problem 12 ---");
            Console.WriteLine($"Sum: {sum12}, Product: {product12}");
            
            // Question: Why use delegates to parameterize mathematical calculations?
            // 1. Separates mathematical operation execution from formula implementation.
            // 2. Permits runtime swapping of math logic (addition, multiplication, etc.).
            // 3. Reduces repetitive calculation wrapper code.
            // 4. Simplifies expansion with new operators without altering method structures.
            // Answer: Parameterized delegates decouple execution logic from mathematical formulas.

            #endregion

            #region Problem 13
            
            List<int> numbers13 = new List<int> { 1, 2, 3 };
            List<string> mapped13 = FunctionalHelpers.Map(numbers13, n => $"Number: {n}");

            Console.WriteLine("\n--- Problem 13 ---");
            Console.WriteLine(string.Join(", ", mapped13));
            
            // Question: How do generic transformation delegates map elements between different types?
            // 1. Accepts input type T and projects it into return type R.
            // 2. Maintained compile-time type checking for input and output types.
            // 3. Forms the foundation of functional mapping methods like LINQ's Select.
            // 4. Converts collections without requiring intermediate casting.
            // Answer: Generic delegate mapping safely transforms data structures across distinct types.

            #endregion

            #region Problem 14
            
            Func<int, int> squareFunc = x => x * x;
            List<int> nums14 = new List<int> { 1, 2, 3, 4 };
            List<int> squared14 = FunctionalHelpers.Transform(nums14, squareFunc);

            Console.WriteLine("\n--- Problem 14 ---");
            Console.WriteLine("Squared: " + string.Join(", ", squared14));
            
            // Question: What is the primary role of Func<T, TResult> in element transformations?
            // 1. Encapsulates a function that accepts input parameter T and returns result TResult.
            // 2. Simplifies method signatures by removing custom delegate declarations.
            // 3. Enables clean inline lambda expressions for math operations.
            // 4. Integrates natively with standard modern C# collection methods.
            // Answer: Func<T, TResult> provides a standard functional signature for type projection.

            #endregion

            #region Problem 15
            // Question: When should Action<T> be selected instead of Func<T, TResult>?
            // 1. When performing void-returning operations that execute side effects.
            // 2. For logging, console printing, or updating external application states.
            // 3. When no return value is required or produced.
            // 4. To explicitly signal procedural execution intent in signatures.
            // Answer: Use Action<T> exclusively for void-returning side-effect actions.

            Console.WriteLine("\n--- Problem 15 ---");
            List<string> names15 = new List<string> { "Alice", "Bob" };
            Action<string> printAction = s => Console.WriteLine($"Hello, {s}");
            FunctionalHelpers.ProcessList(names15, printAction);
            #endregion

            #region Problem 16
                        Predicate<int> isEven16 = x => x % 2 == 0;
            List<int> numbers16 = new List<int> { 1, 2, 3, 4, 5, 6 };
            List<int> evens16 = FunctionalHelpers.Filter(numbers16, isEven16);

            Console.WriteLine("\n--- Problem 16 ---");
            Console.WriteLine("Evens: " + string.Join(", ", evens16));
            
            // Question: Why is Predicate<T> specifically tailored for collection evaluation?
            // 1. Represents a delegate returning bool for a given input element T.
            // 2. Expresses evaluation conditions cleanly in filtering pipelines.
            // 3. Directly maps to array and list methods like FindAll or RemoveAll.
            // 4. Enhances readability for boolean matching routines.
            // Answer: Predicate<T> standardizes single-parameter conditional matching returning boolean.


            #endregion

            #region Problem 17
            
            List<string> words17 = new List<string> { "Apple", "Banana", "Avocado", "Cherry" };
            List<string> startsWithA = FunctionalHelpers.Filter(words17, delegate (string s)
            {
                return s.StartsWith("A");
            });

            Console.WriteLine("\n--- Problem 17 ---");
            Console.WriteLine("Starts with A: " + string.Join(", ", startsWithA));
            
            // Question: How do anonymous functions support inline filtering logic?
            // 1. Embeds dedicated logic directly inside call site parameters.
            // 2. Prevents polluting class definitions with single-use filter methods.
            // 3. Retains access to outer scope variables via closure mechanics.
            // 4. Maintains clear functional isolation.
            // Answer: Anonymous functions allow localized conditional logic directly at execution sites.

            #endregion

            #region Problem 18
            
            int sum18 = FunctionalHelpers.Calculate(10, 20, delegate (int x, int y)
            {
                return x + y;
            });

            Console.WriteLine("\n--- Problem 18 ---");
            Console.WriteLine($"Calculated Sum: {sum18}");
            
            // Question: Where are anonymous functions best applied for mathematical tasks?
            // 1. Single-use mathematical evaluations localized to specific call sites.
            // 2. Situations where declaring named methods adds unnecessary verbosity.
            // 3. Operations that do not require independent unit test coverage.
            // 4. Contexts requiring explicit block syntax with local state declarations.
            // Answer: Best for quick, localized calculations where named methods are unneeded.

            #endregion

            #region Problem 19
            
            List<string> words19 = new List<string> { "Cat", "Elephant", "Dog", "Eagle" };
            List<string> filtered19 = FunctionalHelpers.Filter(words19, s => s.Length > 3 && s.Contains('e'));

            Console.WriteLine("\n--- Problem 19 ---");
            Console.WriteLine("Filtered Words: " + string.Join(", ", filtered19));
            
            // Question: Why are lambdas the preferred modern format for multi-condition filtering?
            // 1. Provides a highly readable, concise single-line expression syntax.
            // 2. Combines multiple logical operations (&&, ||) intuitively.
            // 3. Eliminates parameter type annotations through modern C# type inference.
            // 4. Integrates seamlessly with LINQ and functional pipelines.
            // Answer: Lambdas deliver maximum readability and concise multi-condition syntax.

            #endregion

            #region Problem 20
            
            double div20 = FunctionalHelpers.ExecuteMath(10.0, 2.0, (a, b) => a / b);
            double pow20 = FunctionalHelpers.ExecuteMath(2.0, 3.0, (a, b) => Math.Pow(a, b));

            Console.WriteLine("\n--- Problem 20 ---");
            Console.WriteLine($"Division: {div20}, Exponentiation: {pow20}");

            // Question: How do double-parameter lambdas elevate inline arithmetic execution?
            // 1. Accepts two input parameters cleanly without parameter type declarations.
            // 2. Expresses complex mathematical formulas directly inline.
            // 3. Executes arithmetic functions via delegates without helper classes.
            // 4. Maximizes expressiveness for generic math utilities.
            // Answer: Double lambdas express multi-variable mathematical operations concisely inline.

            #endregion

            // --------------------------------- part 2 --------------------------------



        }
    }
}