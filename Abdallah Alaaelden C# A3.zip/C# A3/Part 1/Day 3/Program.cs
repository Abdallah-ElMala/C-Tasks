﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq.Expressions;
using System.Numerics;
using System.Text;
using System.Xml;

namespace Day_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Problem 1
            ////Problem 1
            //Console.WriteLine("Enter your age");
            //String S1 = Console.ReadLine();
            //// int.parse()
            //try
            //{
            //    int x1 = int.Parse(S1);
            //    Console.WriteLine($"int.parse --> {x1}");
            //}
            //catch (FormatException)
            //{ Console.WriteLine("Error -> put a correct numeric format"); }
            //catch (OverflowException)
            //{ Console.WriteLine("Error -> number is too large or too small"); }
            //catch (ArgumentNullException)
            //{ Console.WriteLine("Error -> input can't be null"); }

            //// toint32()
            //try
            //{
            //    int x2 = Convert.ToInt32((String)S1);
            //    Console.WriteLine(x2);
            //}
            //catch (FormatException)
            //{ Console.WriteLine("Error -> put a correct numeric format"); }
            //catch (OverflowException)
            //{ Console.WriteLine("Error -> number is too large or too small"); }
            #endregion

            #region Question 1
            // Question 1 -->  difference between int.Parse and Convert.ToInt32 when handling null inputs ?
            // int.parse(null) -> it strictly expects a non-null string value
            // Convert.ToInt32(null) -> it handles null by returning the default value of an integer 
            #endregion

            #region Problem 2
            ////Problem 2
            //Console.WriteLine("Enter number");
            //String s = Console.ReadLine();

            //if ( int.TryParse(s, out int x ))
            //{ Console.WriteLine($"Valid number : {x}"); }
            //else
            //{ Console.WriteLine("invalid integer number"); } 
            #endregion

            #region Question 2
            //Question 2 --> why Tryparse over parse
            // no exception which hurts performance Tryparse simply returns false 
            // prevents unhandled runtime errors when users type invalid text or number that are too large 
            // allow simple if/else checks instead of wrapping code in heavy try - catch blocks 
            #endregion

            #region Problem 3
            //// Problem 3
            //object obj;
            //obj = 50;
            //Console.WriteLine($"value: {obj} , Hashcode: {obj.GetHashCode()}");
            //obj = 50.50;
            //Console.WriteLine($"value: {obj} , Hashcode: {obj.GetHashCode()}");
            //obj = "Love u <3 ";
            //Console.WriteLine($"value: {obj} , Hashcode: {obj.GetHashCode()}"); 
            #endregion

            #region Question 3
            // Question 3 ->  real purpose of the GetHashCode() method. 
            // 1.is to generates a numerical integer id to quickly locate objects in dictionaries and hash sets
            // 2.it speed up from O(N) linear search to O(1) instant retrieval
            // 3.if 2 objects are equals , they must return the exact same hash code 
            #endregion

            #region Problem 4
            ////Problem 4
            //object[] obj1 = new object[] { 40 };
            //object[] obj2 = obj1;
            //obj1[0] = 50;
            //Console.WriteLine($"value of Reference = {obj2[0]}"); 
            #endregion

            #region Question 4
            // Question 4 --> What is the significance of reference equality in .NET?
            // it means 2 variables point to the exact same memory location on the heap
            // changing the data through one variable auto changes it for the other one 
            // it save the memory and boosts speed by avoiding unnecessary objects copies in memory 
            #endregion

            #region Problem 5
            ////Problem 5
            //string S1 = new string("Hi");
            //Console.WriteLine($"S1 = {S1}");
            //Console.WriteLine($"Hashcode before: {S1.GetHashCode()}");
            //S1 = "Hi Willy";
            //Console.WriteLine($"S1 = {S1}");
            //Console.WriteLine($"Hashcode after: {S1.GetHashCode()}"); 
            #endregion

            #region Question 5
            // Question 5 --> Why string is immutable in C# ? 
            // 1.Strings cannot be changed after creation 
            // 2.Modifying a string creates a new object in memory
            // 3.it is safe to share across threads without bugs
            // 4.prevents tampering with with sensitive data like paths or passwords
            // 5.Allows C# reude identical string
            // 6.the hashcode stays constant and reliable  
            #endregion

            #region Problem 6
            //// problem 6
            //StringBuilder sb = new StringBuilder("Hi ");
            //Console.WriteLine($"vakue before modify : {sb}");
            //Console.WriteLine($"hashcode before: {sb.GetHashCode()}");
            //sb.Append("Willy");
            //Console.WriteLine($"vakue after modify : {sb}");
            //Console.WriteLine($"hashcode after: {sb.GetHashCode()}"); 
            #endregion

            #region Question 6
            // Question 6 --> How does StringBuilder address the inefficiencies of string concatenation?
            // 1.StringBuilder changes text inside the same memory block , avoiding new object allocations
            // 2.uses an expandable internal array to perform modifications in-place
            // 3.reduce garbage collection overhead and runs append operations much faster  
            #endregion

            #region *Question 
            // Question --> Why is StringBuilder faster for large-scale string modifications? 
            // 1.reuses its internal array buffer instead of creating new objects in memory
            // 2.Avoids allocating thousands of temporary string objects on heap
            // 3.runs append operation in O(1) amortized time instead of O(N^2) for String concatienation 
            #endregion

            #region Problem 7
            //// Problem 7
            //Console.WriteLine("Enter 1st number: ");
            //int input1 = int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter 2nd number: ");
            //int input2 = int.Parse(Console.ReadLine());

            //int sum = input1 + input2;
            //// 1
            //Console.WriteLine("sum is "+ input1 + " + " + input2 + " = " + sum);
            //// 2 
            //Console.WriteLine(string.Format("sum is {0} + {1} = {2}",input1,input2,sum));
            //// 3 
            //Console.WriteLine($"sum is {input1} + {input2} = {sum}"); 
            #endregion

            #region QUestion 7
            // Question 7 --> Which string formatting method is most used and why? 
            // 1. String interpolation ($) is the most used because embedded variables make code clean and easy to maintain.
            // 2.Provides compile - time checking for variables, preventing index error bugs found in composite formatting.
            // 3.Compiles directly into string.Format under the hood without the messy syntax of concatenation operators(+). 
            #endregion

            #region Problem 8
            ////Problem 8
            //StringBuilder sb = new StringBuilder("Hello ");
            //sb.Append("Its Me");
            //Console.WriteLine($"After Append -> {sb}");
            //sb.Replace("Its Me","C#");
            //Console.WriteLine($"After replace -> {sb}");
            //sb.Insert(6,"i love ");
            //Console.WriteLine($"After insert -> {sb} ");
            //sb.Remove(6,7);
            //Console.WriteLine($"After remove -> {sb}"); 
            #endregion

            #region Question 8
            //Question 8 --> Explain how StringBuilder is designed to handle frequent modifications compared to strings.
            // 1. Modifies characters inside its existing memory space without creating new objects.
            // 2. Uses an expandable array that automatically expands capacity as needed.
            // 3. Prevents unnecessary memory allocations and reduces heap cleanup load.  
            #endregion


        }
    }
}
