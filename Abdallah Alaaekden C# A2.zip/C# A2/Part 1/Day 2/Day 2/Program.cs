﻿//using Day_2;
using System;
using System.Drawing;
using System.Threading;


namespace Day_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // ------------------------------ part 1 --------------------------------

            #region Problem 1
            // problem 1
            // first we intialize 2 variables x and y (single line comment)
            //int x = 10;
            //int y = 20; 
            /* second we calculate the sum of x and y then print it (multi-line comment) */
            //int sum = x + y;
            //Console.WriteLine(sum);  
            #endregion

            #region Question 1
            // Question 1 --> shortcut to comment and uncomment: 
            // Ctrl + K + C to comment, Ctrl + K + U to uncomment 
            #endregion

            #region Problem 2
            // problem 2
            // first error we cant use double quotes to assign integer variable.
            // second error we dont initialize variable y
            // third error the c at console.WriteLine is not capitalized
            //int x = 10, y = 20;
            //Console.WriteLine(x + y); 
            #endregion

            #region Question 2
            // Question 2 -->  difference between a runtime error and a logical error 
            // 1. logical error is when the program runs but gives wrong output. Example -> 4 + 4 = 10 or 9 anything that is not correct
            // 2. runtime error (Exception) is when the program crashes or stops working. Example -> 6 / 0 
            // logical error -> syntax is correct but the output is wrong , runtime error --> syntax is correct but the program crashes 
            #endregion

            #region Problem 3
            // problem 3
            //String FullName = "Abdallah Alaaeldin El-Mala";
            //int Age = 20;
            //double Salary = 8000.0;
            //bool IsStudent = true; 
            #endregion

            #region Question 3
            // Question 3 --> why it is important to follow naming conventions
            // 1. readability -> make the code easier to read and understand
            // 2. maintainability -> makes the code easier to understand and modify
            // 3. professionalism -> shows that the developer is experienced and cares about code quality 
            #endregion

            #region Problem 4
            //Problem 4
            //Class1 person1 = new Class1();
            //person1.Name = "Abdallah Alaaeldin El-Mala";
            //Console.WriteLine(person1.Name);
            //Class1 person2 = new Class1();
            //person2 = person1;
            //Console.WriteLine(person2.Name);
            //person2.Name = "to the beautiful one who correct the assignments <3 u :) ";
            //Console.WriteLine(person1.Name);
            #endregion

            #region Question 4
            // Question 4 --> diffrence between value types and reference types
            // * Value Types -> int, double, bool, struct *
            // 1. Memory Location: Stores the actual data value directly on the Stack memory
            // 2. Copy Behavior: Copying a variable creates an independent copy of the value (changing one doesnt affect the other)
            // 3. Lifetime & Cleanup: Automatically deleted from memory as soon as the method or scope ends
            // * Reference Types -> class, string, array * 
            // 1. Memory Location: Stores the actual object on the Heap memory, while the variable on the Stack holds only a pointer (memory address).
            // 2. Copy Behavior: Copying a variable copies only the memory address, so both variables point to the exact same object.
            // 3. Lifetime & Cleanup: Managed and removed from the Heap later by the Garbage Collector when no longer in use. 
            #endregion

            #region Problem 5
            // Problem 5
            //int x = 15, y = 4;
            //int Sum = x + y , diff = x - y , prod = x * y;
            //double div = x / y , remiander = x % y;
            //Console.WriteLine(Sum);
            //Console.WriteLine(diff);
            //Console.WriteLine(prod);
            //Console.WriteLine(div);
            //Console.WriteLine(remiander); 
            #endregion

            #region Question 5
            //Question 5 -->  What will be the output ? Explain why
            //int a = 2, b = 7;
            //Console.WriteLine(a % b);
            // Output: 2
            //because in modulus operation if the first number is less than the second number the output will be the first number
            #endregion

            #region Problem 6
            // Problem 6
            //int x = int.Parse(Console.ReadLine());
            //if (x > 10)
            //{
            //    Console.WriteLine(x + " is greater than 10");
            //}
            //else if (x == 10)
            //{
            //    Console.WriteLine(x + " is equal to 10");
            //}
            //else
            //{
            //    Console.WriteLine(x + " is less than 10");
            //} 

            //---------------- Even ------------------
            //int x = int.Parse(Console.ReadLine());
            //if (x % 2 == 0)
            //{
            //    Console.WriteLine(x + " is even");
            //}
            //else
            //{
            //    Console.WriteLine(x + " is odd");
            //}
            #endregion

            #region Question 6
            // Question 6 --> difference between logical AND (&&) and bitwise AND (&)
            // Logical AND (&&)
            // 1.Data Type -> Works ONLY with boolean conditions.
            // 2.Short -> Skips evaluating the right side if the left side is false.
            // 3.Safety & Speed -> Faster and prevents crashes

            // Bitwise AND (&)
            // 1.Data Types -> Works with integer types (int, byte, long) AND boolean types.
            // 2.No Short -> Always evaluates BOTH sides when used with boolean conditions.
            // 3.Bit Manipulation -> Compares numbers bit - by - bit (ex: 6 & 3 = 2)  
            #endregion

            #region Problem 7
            // problem 7
            //double d01 = Convert.ToDouble(Console.ReadLine());
            //int Explicit = (int) d01;
            //double Implicit = Explicit ;
            //Console.WriteLine("normal double = " + d01);
            //Console.WriteLine("explicit = " + Explicit);
            //Console.WriteLine("implicit = " + Implicit); 
            #endregion

            #region Question 7
            // Question 7 --> Why is explicit casting required when converting a double to an int
            /* Explicit casting is required When you convert a double to an int,
             * you may lose the decimal part,
             * so you need to explicitly tell the compiler that you are aware of this loss of data */
            #endregion

            #region Problem 8
            // Problem 8
            //Console.WriteLine("write your age");
            //String StrAge = Console.ReadLine();
            //int Age = int.Parse(StrAge);
            //if (Age > 0)
            //    Console.WriteLine("Age is valid " + Age);
            //else
            //    Console.WriteLine("Invalid age "); 
            #endregion

            #region Question 8
            //Question 8 --> What exception might occur if the input is invalid and how can you handle it
            // 1.when the input string contains characters or Decimal number 
            // 2.when the input is overflow
            // 3.when the input contains null value
            //** and how can you handle it **
            // 1.use try-catch method to handle specific exceptions individually
            // 2.use tryparse method (Defensive Parsing)
            // Instead of catching exceptions , It attempts conversion without throwing exceptions and returns true or false 
            #endregion

            #region Problem 9
            // problem 9
            //int x = 9;
            //int PreRes = ++x;
            //x = 9; 
            //int PostRes = x++;
            //Console.WriteLine(" x = 9 ");
            //Console.WriteLine("prefix ++x: " + PreRes);
            //Console.WriteLine("x After prefix: " + x);
            //Console.WriteLine(" x = 9 ");
            //Console.WriteLine("postfix x++: " + PostRes);
            //Console.WriteLine("x After postfix: " + x); 
            #endregion

            #region Question 9
            // Question 9 --> what is the value of x after execution? Explain why
            //int x = 5;
            //int y = ++x + x++;
            // 1.Initial State: x = 9
            // 2.Left Side(++x) : Prefix increment -> x becomes 6, passes 6 to expression.
            // 3.Right Side(x++): Postfix increment -> passes current x (6) to expression, then increments x to 7.
            // so the final value of x is 7  
            #endregion

        }
    }
}